package com.employeehub.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
