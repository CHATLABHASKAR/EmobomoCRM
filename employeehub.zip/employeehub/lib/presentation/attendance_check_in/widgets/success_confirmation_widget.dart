import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';

class SuccessConfirmationWidget extends StatefulWidget {
  final bool isVisible;
  final bool isCheckIn;
  final String timestamp;
  final String location;
  final VoidCallback? onDismiss;

  const SuccessConfirmationWidget({
    Key? key,
    required this.isVisible,
    required this.isCheckIn,
    required this.timestamp,
    required this.location,
    this.onDismiss,
  }) : super(key: key);

  @override
  State<SuccessConfirmationWidget> createState() =>
      _SuccessConfirmationWidgetState();
}

class _SuccessConfirmationWidgetState extends State<SuccessConfirmationWidget>
    with TickerProviderStateMixin {
  late AnimationController _slideController;
  late AnimationController _checkController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _checkAnimation;

  @override
  void initState() {
    super.initState();

    _slideController = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );

    _checkController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutBack,
    ));

    _checkAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _checkController,
      curve: Curves.elasticOut,
    ));
  }

  @override
  void didUpdateWidget(SuccessConfirmationWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isVisible != oldWidget.isVisible) {
      if (widget.isVisible) {
        _slideController.forward();
        Future.delayed(const Duration(milliseconds: 200), () {
          if (mounted) {
            _checkController.forward();
          }
        });

        // Auto dismiss after 3 seconds
        Future.delayed(const Duration(seconds: 3), () {
          if (mounted && widget.isVisible) {
            _dismissConfirmation();
          }
        });
      } else {
        _slideController.reverse();
        _checkController.reset();
      }
    }
  }

  @override
  void dispose() {
    _slideController.dispose();
    _checkController.dispose();
    super.dispose();
  }

  void _dismissConfirmation() {
    _slideController.reverse().then((_) {
      if (mounted) {
        widget.onDismiss?.call();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isVisible) return const SizedBox.shrink();

    final bool isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: SlideTransition(
        position: _slideAnimation,
        child: Container(
          margin: EdgeInsets.all(4.w),
          padding: EdgeInsets.all(6.w),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color:
                  AppTheme.getSuccessColor(!isDarkMode).withValues(alpha: 0.3),
              width: 2,
            ),
            boxShadow: [
              BoxShadow(
                color: AppTheme.getSuccessColor(!isDarkMode)
                    .withValues(alpha: 0.2),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Success Icon with Animation
              AnimatedBuilder(
                animation: _checkAnimation,
                builder: (context, child) {
                  return Transform.scale(
                    scale: _checkAnimation.value,
                    child: Container(
                      width: 16.w,
                      height: 16.w,
                      decoration: BoxDecoration(
                        color: AppTheme.getSuccessColor(!isDarkMode),
                        shape: BoxShape.circle,
                      ),
                      child: CustomIconWidget(
                        iconName: 'check',
                        color: Colors.white,
                        size: 32,
                      ),
                    ),
                  );
                },
              ),

              SizedBox(height: 3.h),

              // Success Message
              Text(
                'Attendance Recorded',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: AppTheme.getSuccessColor(!isDarkMode),
                      fontWeight: FontWeight.w700,
                    ),
              ),

              SizedBox(height: 1.h),

              Text(
                widget.isCheckIn
                    ? 'You have successfully checked in'
                    : 'You have successfully checked out',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
              ),

              SizedBox(height: 3.h),

              // Details Container
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: AppTheme.getSuccessColor(!isDarkMode)
                      .withValues(alpha: 0.05),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: AppTheme.getSuccessColor(!isDarkMode)
                        .withValues(alpha: 0.1),
                    width: 1,
                  ),
                ),
                child: Column(
                  children: [
                    // Timestamp
                    Row(
                      children: [
                        CustomIconWidget(
                          iconName: 'access_time',
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                          size: 18,
                        ),
                        SizedBox(width: 3.w),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Time',
                                style: Theme.of(context)
                                    .textTheme
                                    .labelSmall
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceVariant,
                                    ),
                              ),
                              Text(
                                widget.timestamp,
                                style: AppTheme.dataTextStyle(
                                  isLight: !isDarkMode,
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),

                    SizedBox(height: 2.h),

                    // Location
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomIconWidget(
                          iconName: 'location_on',
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                          size: 18,
                        ),
                        SizedBox(width: 3.w),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Location',
                                style: Theme.of(context)
                                    .textTheme
                                    .labelSmall
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceVariant,
                                    ),
                              ),
                              Text(
                                widget.location,
                                style: Theme.of(context)
                                    .textTheme
                                    .bodySmall
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurface,
                                      height: 1.3,
                                    ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              SizedBox(height: 3.h),

              // Dismiss Button
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: _dismissConfirmation,
                  child: Text('Continue'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
