import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';

class CheckInButtonWidget extends StatefulWidget {
  final bool isCheckedIn;
  final bool isLoading;
  final VoidCallback? onTap;
  final String currentTime;

  const CheckInButtonWidget({
    Key? key,
    required this.isCheckedIn,
    required this.isLoading,
    this.onTap,
    required this.currentTime,
  }) : super(key: key);

  @override
  State<CheckInButtonWidget> createState() => _CheckInButtonWidgetState();
}

class _CheckInButtonWidgetState extends State<CheckInButtonWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 0.95,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));

    _pulseAnimation = Tween<double>(
      begin: 1.0,
      end: 1.1,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));

    if (!widget.isLoading) {
      _animationController.repeat(reverse: true);
    }
  }

  @override
  void didUpdateWidget(CheckInButtonWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isLoading != oldWidget.isLoading) {
      if (widget.isLoading) {
        _animationController.stop();
      } else {
        _animationController.repeat(reverse: true);
      }
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Column(
      children: [
        // Current Time Display
        Container(
          padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Theme.of(context).shadowColor.withValues(alpha: 0.1),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Text(
            widget.currentTime,
            style: AppTheme.dataTextStyle(
              isLight: !isDarkMode,
              fontSize: 18.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),

        SizedBox(height: 4.h),

        // Check-in Button
        AnimatedBuilder(
          animation: _animationController,
          builder: (context, child) {
            return Transform.scale(
              scale: widget.isLoading ? 1.0 : _pulseAnimation.value,
              child: GestureDetector(
                onTapDown: (_) {
                  if (!widget.isLoading) {
                    _animationController.forward();
                  }
                },
                onTapUp: (_) {
                  if (!widget.isLoading) {
                    _animationController.reverse();
                    widget.onTap?.call();
                  }
                },
                onTapCancel: () {
                  if (!widget.isLoading) {
                    _animationController.reverse();
                  }
                },
                child: Transform.scale(
                  scale: widget.isLoading ? 1.0 : _scaleAnimation.value,
                  child: Container(
                    width: 60.w,
                    height: 60.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: widget.isCheckedIn
                            ? [
                                AppTheme.getWarningColor(!isDarkMode),
                                AppTheme.getWarningColor(!isDarkMode)
                                    .withValues(alpha: 0.8),
                              ]
                            : [
                                Theme.of(context).colorScheme.primary,
                                Theme.of(context)
                                    .colorScheme
                                    .primary
                                    .withValues(alpha: 0.8),
                              ],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: (widget.isCheckedIn
                                  ? AppTheme.getWarningColor(!isDarkMode)
                                  : Theme.of(context).colorScheme.primary)
                              .withValues(alpha: 0.3),
                          blurRadius: 20,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: widget.isLoading
                        ? Center(
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 3,
                            ),
                          )
                        : Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CustomIconWidget(
                                iconName:
                                    widget.isCheckedIn ? 'logout' : 'login',
                                color: Colors.white,
                                size: 32,
                              ),
                              SizedBox(height: 1.h),
                              Text(
                                widget.isCheckedIn ? 'CHECK OUT' : 'CHECK IN',
                                style: Theme.of(context)
                                    .textTheme
                                    .titleMedium
                                    ?.copyWith(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 1.2,
                                    ),
                              ),
                            ],
                          ),
                  ),
                ),
              ),
            );
          },
        ),

        SizedBox(height: 3.h),

        // Instruction Text
        Text(
          widget.isLoading
              ? 'Verifying location...'
              : widget.isCheckedIn
                  ? 'Tap to Check Out'
                  : 'Tap to Check In',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
                fontWeight: FontWeight.w500,
              ),
        ),
      ],
    );
  }
}
