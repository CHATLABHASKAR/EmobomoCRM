import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';

class LocationStatusWidget extends StatelessWidget {
  final String locationAccuracy;
  final bool isLocationEnabled;
  final VoidCallback? onLocationTap;

  const LocationStatusWidget({
    Key? key,
    required this.locationAccuracy,
    required this.isLocationEnabled,
    this.onLocationTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bool isDarkMode = Theme.of(context).brightness == Brightness.dark;

    Color statusColor;
    String statusText;

    if (!isLocationEnabled) {
      statusColor = AppTheme.getWarningColor(!isDarkMode);
      statusText = 'GPS Disabled';
    } else {
      switch (locationAccuracy.toLowerCase()) {
        case 'high':
          statusColor = AppTheme.getSuccessColor(!isDarkMode);
          statusText = 'High Accuracy';
          break;
        case 'medium':
          statusColor = AppTheme.getWarningColor(!isDarkMode);
          statusText = 'Medium Accuracy';
          break;
        case 'low':
          statusColor = AppTheme.errorLight;
          statusText = 'Low Accuracy';
          break;
        default:
          statusColor = AppTheme.getWarningColor(!isDarkMode);
          statusText = 'Locating...';
      }
    }

    return GestureDetector(
      onTap: onLocationTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
        decoration: BoxDecoration(
          color: statusColor.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: statusColor.withValues(alpha: 0.3),
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 2.w,
              height: 2.w,
              decoration: BoxDecoration(
                color: statusColor,
                shape: BoxShape.circle,
              ),
            ),
            SizedBox(width: 2.w),
            Text(
              statusText,
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    color: statusColor,
                    fontWeight: FontWeight.w500,
                  ),
            ),
            SizedBox(width: 1.w),
            CustomIconWidget(
              iconName: 'location_on',
              color: statusColor,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }
}
