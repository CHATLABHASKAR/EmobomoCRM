import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/biometric_prompt_widget.dart';
import './widgets/check_in_button_widget.dart';
import './widgets/location_display_widget.dart';
import './widgets/location_status_widget.dart';
import './widgets/manual_entry_widget.dart';
import './widgets/photo_capture_widget.dart';
import './widgets/success_confirmation_widget.dart';

class AttendanceCheckIn extends StatefulWidget {
  const AttendanceCheckIn({Key? key}) : super(key: key);

  @override
  State<AttendanceCheckIn> createState() => _AttendanceCheckInState();
}

class _AttendanceCheckInState extends State<AttendanceCheckIn>
    with TickerProviderStateMixin {
  // Mock attendance data
  final Map<String, dynamic> _attendanceData = {
    "employee_id": "EMP001",
    "employee_name": "John Smith",
    "current_status": "checked_out", // checked_in, checked_out
    "last_check_in": "2025-07-18T08:30:00Z",
    "last_check_out": "2025-07-18T17:45:00Z",
    "location_accuracy": "high", // high, medium, low
    "is_location_enabled": true,
    "current_address":
        "123 Business Plaza, Suite 400, Downtown District, New York, NY 10001",
    "office_location": {
      "latitude": 40.7589,
      "longitude": -73.9851,
      "address":
          "123 Business Plaza, Suite 400, Downtown District, New York, NY 10001"
    },
    "distance_from_office": 25.0,
    "is_within_office_radius": true,
    "office_radius": 100.0,
    "work_schedule": {
      "start_time": "09:00",
      "end_time": "18:00",
      "break_start": "12:00",
      "break_end": "13:00"
    },
    "attendance_history": [
      {
        "date": "2025-07-18",
        "check_in": "08:30:00",
        "check_out": "17:45:00",
        "status": "present",
        "location": "Office"
      },
      {
        "date": "2025-07-17",
        "check_in": "08:45:00",
        "check_out": "18:00:00",
        "status": "present",
        "location": "Office"
      }
    ]
  };

  // State variables
  bool _isLoading = false;
  bool _showBiometricPrompt = false;
  bool _showSuccessConfirmation = false;
  bool _showManualEntry = false;
  bool _showPhotoCapture = false;
  String _currentTime = '';
  XFile? _capturedPhoto;

  @override
  void initState() {
    super.initState();
    _updateCurrentTime();
    _startTimeUpdater();
  }

  void _updateCurrentTime() {
    final now = DateTime.now();
    setState(() {
      _currentTime =
          '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}';
    });
  }

  void _startTimeUpdater() {
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted) {
        _updateCurrentTime();
        _startTimeUpdater();
      }
    });
  }

  bool get _isCheckedIn =>
      (_attendanceData["current_status"] as String) == "checked_in";

  void _handleCheckInOut() {
    if (!_isLocationValid()) {
      _showLocationError();
      return;
    }

    setState(() {
      _isLoading = true;
    });

    // Simulate GPS verification
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _showBiometricPrompt = true;
        });
      }
    });
  }

  bool _isLocationValid() {
    return (_attendanceData["is_location_enabled"] as bool) &&
        (_attendanceData["is_within_office_radius"] as bool);
  }

  void _showLocationError() {
    String message;
    if (!(_attendanceData["is_location_enabled"] as bool)) {
      message = 'GPS is disabled. Please enable location services to check in.';
    } else if (!(_attendanceData["is_within_office_radius"] as bool)) {
      message =
          'You are outside the office area. Please move closer to the office to check in.';
    } else {
      message = 'Location verification failed. Please try again.';
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppTheme.errorLight,
        behavior: SnackBarBehavior.floating,
        action: SnackBarAction(
          label: 'Manual Entry',
          textColor: Colors.white,
          onPressed: () {
            setState(() {
              _showManualEntry = true;
            });
          },
        ),
      ),
    );
  }

  void _handleBiometricAuthentication() {
    setState(() {
      _showBiometricPrompt = false;
    });
    _processAttendance();
  }

  void _handleBiometricCancel() {
    setState(() {
      _showBiometricPrompt = false;
    });
  }

  void _handleBiometricFallback() {
    setState(() {
      _showBiometricPrompt = false;
      _showPhotoCapture = true;
    });
  }

  void _processAttendance() {
    // Update attendance status
    setState(() {
      _attendanceData["current_status"] =
          _isCheckedIn ? "checked_out" : "checked_in";
      if (_isCheckedIn) {
        _attendanceData["last_check_out"] = DateTime.now().toIso8601String();
      } else {
        _attendanceData["last_check_in"] = DateTime.now().toIso8601String();
      }
      _showSuccessConfirmation = true;
    });
  }

  void _handleSuccessConfirmationDismiss() {
    setState(() {
      _showSuccessConfirmation = false;
    });
  }

  void _handleManualEntrySubmit() {
    setState(() {
      _showManualEntry = false;
    });
    _processAttendance();
  }

  void _handleManualEntryCancel() {
    setState(() {
      _showManualEntry = false;
    });
  }

  void _handlePhotoTaken(XFile? photo) {
    setState(() {
      _capturedPhoto = photo;
      _showPhotoCapture = false;
    });
    _processAttendance();
  }

  void _handlePhotoCaptureCancel() {
    setState(() {
      _showPhotoCapture = false;
    });
  }

  void _handleLocationTap() {
    // Simulate location refresh
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Refreshing location...'),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  void _handleMapTap() {
    // Navigate to map view or show map dialog
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Location Map'),
        content: Container(
          width: 80.w,
          height: 40.h,
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomIconWidget(
                  iconName: 'map',
                  color: Theme.of(context).colorScheme.primary,
                  size: 48,
                ),
                SizedBox(height: 2.h),
                Text(
                  'Interactive Map View',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                SizedBox(height: 1.h),
                Text(
                  'Your location: ${_attendanceData["current_address"]}',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: Stack(
        children: [
          // Main Content
          SafeArea(
            child: Column(
              children: [
                // Header
                Container(
                  padding: EdgeInsets.all(4.w),
                  child: Row(
                    children: [
                      IconButton(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: CustomIconWidget(
                          iconName: 'close',
                          color: Theme.of(context).colorScheme.onSurface,
                          size: 24,
                        ),
                      ),
                      Expanded(
                        child: Text(
                          'Attendance Check-in',
                          textAlign: TextAlign.center,
                          style:
                              Theme.of(context).textTheme.titleLarge?.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                        ),
                      ),
                      LocationStatusWidget(
                        locationAccuracy:
                            _attendanceData["location_accuracy"] as String,
                        isLocationEnabled:
                            _attendanceData["is_location_enabled"] as bool,
                        onLocationTap: _handleLocationTap,
                      ),
                    ],
                  ),
                ),

                // Scrollable Content
                Expanded(
                  child: SingleChildScrollView(
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    child: Column(
                      children: [
                        SizedBox(height: 2.h),

                        // Employee Info
                        Container(
                          width: double.infinity,
                          padding: EdgeInsets.all(4.w),
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.surface,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(
                                color: Theme.of(context)
                                    .shadowColor
                                    .withValues(alpha: 0.1),
                                blurRadius: 8,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 12.w,
                                height: 12.w,
                                decoration: BoxDecoration(
                                  color: Theme.of(context)
                                      .colorScheme
                                      .primary
                                      .withValues(alpha: 0.1),
                                  shape: BoxShape.circle,
                                ),
                                child: CustomIconWidget(
                                  iconName: 'person',
                                  color: Theme.of(context).colorScheme.primary,
                                  size: 24,
                                ),
                              ),
                              SizedBox(width: 3.w),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      _attendanceData["employee_name"]
                                          as String,
                                      style: Theme.of(context)
                                          .textTheme
                                          .titleMedium
                                          ?.copyWith(
                                            fontWeight: FontWeight.w600,
                                          ),
                                    ),
                                    Text(
                                      'ID: ${_attendanceData["employee_id"]}',
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodySmall
                                          ?.copyWith(
                                            color: Theme.of(context)
                                                .colorScheme
                                                .onSurfaceVariant,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 3.w, vertical: 1.w),
                                decoration: BoxDecoration(
                                  color: (_isCheckedIn
                                          ? AppTheme.getSuccessColor(
                                              Theme.of(context).brightness ==
                                                  Brightness.light)
                                          : AppTheme.getWarningColor(
                                              Theme.of(context).brightness ==
                                                  Brightness.light))
                                      .withValues(alpha: 0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  _isCheckedIn ? 'Checked In' : 'Checked Out',
                                  style: Theme.of(context)
                                      .textTheme
                                      .labelSmall
                                      ?.copyWith(
                                        color: _isCheckedIn
                                            ? AppTheme.getSuccessColor(
                                                Theme.of(context).brightness ==
                                                    Brightness.light)
                                            : AppTheme.getWarningColor(
                                                Theme.of(context).brightness ==
                                                    Brightness.light),
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        SizedBox(height: 4.h),

                        // Check-in Button
                        CheckInButtonWidget(
                          isCheckedIn: _isCheckedIn,
                          isLoading: _isLoading,
                          currentTime: _currentTime,
                          onTap: _handleCheckInOut,
                        ),

                        SizedBox(height: 4.h),

                        // Location Display
                        LocationDisplayWidget(
                          currentAddress:
                              _attendanceData["current_address"] as String,
                          isWithinOfficeRadius:
                              _attendanceData["is_within_office_radius"]
                                  as bool,
                          distanceFromOffice:
                              _attendanceData["distance_from_office"] as double,
                          onMapTap: _handleMapTap,
                        ),

                        SizedBox(height: 4.h),

                        // Manual Entry Button
                        if (!_isLocationValid())
                          Container(
                            width: double.infinity,
                            margin: EdgeInsets.symmetric(horizontal: 4.w),
                            child: OutlinedButton.icon(
                              onPressed: () {
                                setState(() {
                                  _showManualEntry = true;
                                });
                              },
                              icon: CustomIconWidget(
                                iconName: 'edit_location',
                                color: AppTheme.getWarningColor(
                                    Theme.of(context).brightness ==
                                        Brightness.light),
                                size: 20,
                              ),
                              label: Text(
                                'Manual Entry',
                                style: TextStyle(
                                  color: AppTheme.getWarningColor(
                                      Theme.of(context).brightness ==
                                          Brightness.light),
                                ),
                              ),
                              style: OutlinedButton.styleFrom(
                                side: BorderSide(
                                  color: AppTheme.getWarningColor(
                                      Theme.of(context).brightness ==
                                          Brightness.light),
                                ),
                                padding: EdgeInsets.symmetric(vertical: 2.h),
                              ),
                            ),
                          ),

                        SizedBox(
                            height: 10.h), // Extra space for floating elements
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Biometric Prompt Overlay
          BiometricPromptWidget(
            isVisible: _showBiometricPrompt,
            onAuthenticated: _handleBiometricAuthentication,
            onCancel: _handleBiometricCancel,
            onFallback: _handleBiometricFallback,
          ),

          // Success Confirmation Overlay
          SuccessConfirmationWidget(
            isVisible: _showSuccessConfirmation,
            isCheckIn:
                !_isCheckedIn, // Opposite because we already updated the status
            timestamp: _currentTime,
            location: _attendanceData["current_address"] as String,
            onDismiss: _handleSuccessConfirmationDismiss,
          ),

          // Manual Entry Overlay
          ManualEntryWidget(
            isVisible: _showManualEntry,
            onSubmit: _handleManualEntrySubmit,
            onCancel: _handleManualEntryCancel,
          ),

          // Photo Capture Overlay
          PhotoCaptureWidget(
            isVisible: _showPhotoCapture,
            onPhotoTaken: _handlePhotoTaken,
            onCancel: _handlePhotoCaptureCancel,
          ),
        ],
      ),
    );
  }
}
