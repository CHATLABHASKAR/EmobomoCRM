import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/attendance_status_card.dart';
import './widgets/dashboard_header.dart';
import './widgets/leave_balance_card.dart';
import './widgets/quick_actions_widget.dart';
import './widgets/recent_requests_card.dart';
import './widgets/upcoming_holidays_card.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({Key? key}) : super(key: key);

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> with TickerProviderStateMixin {
  late TabController _tabController;
  int _currentIndex = 0;
  bool _isConnected = true;
  bool _isRefreshing = false;

  // Mock data
  final Map<String, dynamic> _attendanceData = {
    "isCheckedIn": true,
    "checkInTime": "09:15 AM",
    "totalHours": "7h 45m",
    "status": "Checked In",
  };

  final List<Map<String, dynamic>> _holidays = [
    {
      "name": "Independence Day",
      "date": "04 July",
      "type": "National",
      "daysLeft": 15,
    },
    {
      "name": "Labor Day",
      "date": "02 September",
      "type": "National",
      "daysLeft": 74,
    },
    {
      "name": "Company Anniversary",
      "date": "15 September",
      "type": "Company",
      "daysLeft": 87,
    },
    {
      "name": "Thanksgiving",
      "date": "28 November",
      "type": "National",
      "daysLeft": 161,
    },
  ];

  final List<Map<String, dynamic>> _recentRequests = [
    {
      "type": "Leave Request",
      "status": "Pending",
      "date": "July 25-26",
      "duration": "2 days",
      "hasBadge": true,
    },
    {
      "type": "WFH Request",
      "status": "Approved",
      "date": "July 20",
      "duration": "1 day",
      "hasBadge": false,
    },
    {
      "type": "Sick Leave",
      "status": "Approved",
      "date": "July 15",
      "duration": "1 day",
      "hasBadge": false,
    },
  ];

  final Map<String, dynamic> _leaveBalance = {
    "totalLeaves": 24,
    "usedLeaves": 8,
    "remainingLeaves": 16,
    "leaveTypes": [
      {"type": "Annual Leave", "available": 20, "used": 6},
      {"type": "Sick Leave", "available": 10, "used": 2},
      {"type": "Personal Leave", "available": 5, "used": 0},
      {"type": "Emergency Leave", "available": 3, "used": 0},
    ],
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _tabController.addListener(() {
      setState(() {
        _currentIndex = _tabController.index;
      });
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _handleRefresh() async {
    setState(() {
      _isRefreshing = true;
    });

    // Simulate API call
    await Future.delayed(const Duration(seconds: 2));

    setState(() {
      _isRefreshing = false;
      _isConnected = true;
    });
  }

  void _handleAttendanceAction() {
    Navigator.pushNamed(context, '/attendance-check-in');
  }

  String _getCurrentDate() {
    final now = DateTime.now();
    final months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December'
    ];
    final days = [
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday'
    ];

    return '${days[now.weekday % 7]}, ${months[now.month - 1]} ${now.day}, ${now.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: Column(
        children: [
          DashboardHeader(
            userName: 'John Smith',
            currentDate: _getCurrentDate(),
            isConnected: _isConnected,
          ),
          Container(
            color: AppTheme.lightTheme.colorScheme.surface,
            child: TabBar(
              controller: _tabController,
              tabs: const [
                Tab(text: 'Dashboard'),
                Tab(text: 'Attendance'),
                Tab(text: 'Requests'),
                Tab(text: 'Profile'),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildDashboardTab(),
                _buildPlaceholderTab('Attendance'),
                _buildPlaceholderTab('Requests'),
                _buildPlaceholderTab('Profile'),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: _currentIndex == 0
          ? FloatingActionButton.extended(
              onPressed: _handleAttendanceAction,
              icon: CustomIconWidget(
                iconName: 'access_time',
                color: AppTheme.lightTheme.colorScheme.onPrimary,
                size: 20,
              ),
              label: Text(
                'Quick Check-in',
                style: AppTheme.lightTheme.textTheme.labelLarge?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onPrimary,
                ),
              ),
            )
          : null,
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color:
                  AppTheme.lightTheme.colorScheme.shadow.withValues(alpha: 0.1),
              blurRadius: 8,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
              _tabController.animateTo(index);
            });
          },
          type: BottomNavigationBarType.fixed,
          items: [
            BottomNavigationBarItem(
              icon: CustomIconWidget(
                iconName: 'dashboard',
                color: _currentIndex == 0
                    ? AppTheme.lightTheme.colorScheme.primary
                    : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 24,
              ),
              label: 'Dashboard',
            ),
            BottomNavigationBarItem(
              icon: CustomIconWidget(
                iconName: 'access_time',
                color: _currentIndex == 1
                    ? AppTheme.lightTheme.colorScheme.primary
                    : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 24,
              ),
              label: 'Attendance',
            ),
            BottomNavigationBarItem(
              icon: CustomIconWidget(
                iconName: 'assignment',
                color: _currentIndex == 2
                    ? AppTheme.lightTheme.colorScheme.primary
                    : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 24,
              ),
              label: 'Requests',
            ),
            BottomNavigationBarItem(
              icon: CustomIconWidget(
                iconName: 'person',
                color: _currentIndex == 3
                    ? AppTheme.lightTheme.colorScheme.primary
                    : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 24,
              ),
              label: 'Profile',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDashboardTab() {
    return RefreshIndicator(
      onRefresh: _handleRefresh,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 1.h),
            AttendanceStatusCard(
              attendanceData: _attendanceData,
              onTap: _handleAttendanceAction,
            ),
            QuickActionsWidget(),
            UpcomingHolidaysCard(holidays: _holidays),
            RecentRequestsCard(requests: _recentRequests),
            LeaveBalanceCard(leaveBalance: _leaveBalance),
            SizedBox(height: 10.h), // Space for FAB
          ],
        ),
      ),
    );
  }

  Widget _buildPlaceholderTab(String tabName) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'construction',
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 48,
          ),
          SizedBox(height: 2.h),
          Text(
            '$tabName Coming Soon',
            style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'This feature is under development',
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}
