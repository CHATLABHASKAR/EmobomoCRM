import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/biometric_auth_widget.dart';
import './widgets/company_logo_widget.dart';
import './widgets/help_section_widget.dart';
import './widgets/login_form_widget.dart';
import './widgets/offline_indicator_widget.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _employeeIdController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final FocusNode _employeeIdFocusNode = FocusNode();
  final FocusNode _passwordFocusNode = FocusNode();

  bool _isLoading = false;
  bool _isOffline = false;
  String? _employeeIdError;
  String? _passwordError;
  bool _isBiometricEnabled = false;

  // Mock credentials for testing
  final Map<String, String> _mockCredentials = {
    'john.doe@company.com': 'password123',
    'jane.smith@company.com': 'secure456',
    'EMP001': 'admin123',
    'EMP002': 'user456',
  };

  @override
  void initState() {
    super.initState();
    _initializeScreen();
  }

  @override
  void dispose() {
    _employeeIdController.dispose();
    _passwordController.dispose();
    _employeeIdFocusNode.dispose();
    _passwordFocusNode.dispose();
    super.dispose();
  }

  Future<void> _initializeScreen() async {
    await _loadSavedEmployeeId();
    await _checkConnectivity();
    await _checkBiometricAvailability();
  }

  Future<void> _loadSavedEmployeeId() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedEmployeeId = prefs.getString('saved_employee_id');
      if (savedEmployeeId != null && savedEmployeeId.isNotEmpty) {
        _employeeIdController.text = savedEmployeeId;
        setState(() {
          _isBiometricEnabled = true;
        });
      }
    } catch (e) {
      // Silent fail - not critical for app functionality
    }
  }

  Future<void> _checkConnectivity() async {
    try {
      final connectivityResult = await Connectivity().checkConnectivity();
      setState(() {
        _isOffline = connectivityResult == ConnectivityResult.none;
      });
    } catch (e) {
      setState(() {
        _isOffline = false;
      });
    }
  }

  Future<void> _checkBiometricAvailability() async {
    // In a real app, this would check for biometric hardware availability
    // For now, enable biometric if employee ID is saved
    setState(() {
      _isBiometricEnabled = _employeeIdController.text.isNotEmpty;
    });
  }

  Future<void> _handleLogin() async {
    if (_isOffline) {
      _showOfflineMessage();
      return;
    }

    setState(() {
      _isLoading = true;
      _employeeIdError = null;
      _passwordError = null;
    });

    // Dismiss keyboard
    FocusScope.of(context).unfocus();

    try {
      // Validate inputs
      if (!_validateInputs()) {
        setState(() {
          _isLoading = false;
        });
        return;
      }

      // Simulate network delay
      await Future.delayed(const Duration(seconds: 2));

      // Check credentials
      final employeeId = _employeeIdController.text.trim();
      final password = _passwordController.text.trim();

      if (_mockCredentials.containsKey(employeeId) &&
          _mockCredentials[employeeId] == password) {
        // Save employee ID for future use
        await _saveEmployeeId(employeeId);

        // Success haptic feedback
        HapticFeedback.lightImpact();

        // Show success message
        Fluttertoast.showToast(
          msg: "Login successful!",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: AppTheme.getSuccessColor(true),
          textColor: Colors.white,
        );

        // Navigate to dashboard
        if (mounted) {
          Navigator.pushReplacementNamed(context, '/dashboard');
        }
      } else {
        // Invalid credentials
        setState(() {
          _employeeIdError = 'Invalid employee ID or email';
          _passwordError = 'Invalid password';
        });

        Fluttertoast.showToast(
          msg: "Invalid credentials. Please try again.",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: AppTheme.lightTheme.colorScheme.error,
          textColor: Colors.white,
        );
      }
    } catch (e) {
      // Network or other error
      Fluttertoast.showToast(
        msg: "Login failed. Please check your connection and try again.",
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
        textColor: Colors.white,
      );
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  bool _validateInputs() {
    bool isValid = true;

    if (_employeeIdController.text.trim().isEmpty) {
      setState(() {
        _employeeIdError = 'Employee ID or email is required';
      });
      isValid = false;
    }

    if (_passwordController.text.trim().isEmpty) {
      setState(() {
        _passwordError = 'Password is required';
      });
      isValid = false;
    } else if (_passwordController.text.trim().length < 6) {
      setState(() {
        _passwordError = 'Password must be at least 6 characters';
      });
      isValid = false;
    }

    return isValid;
  }

  Future<void> _saveEmployeeId(String employeeId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('saved_employee_id', employeeId);
    } catch (e) {
      // Silent fail - not critical
    }
  }

  Future<void> _handleBiometricAuth() async {
    if (!_isBiometricEnabled || _employeeIdController.text.trim().isEmpty) {
      Fluttertoast.showToast(
        msg: "Please enter your employee ID first",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
      );
      return;
    }

    try {
      // In a real app, this would use local_auth package
      // For demo purposes, simulate biometric success
      HapticFeedback.lightImpact();

      Fluttertoast.showToast(
        msg: "Biometric authentication successful!",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: AppTheme.getSuccessColor(true),
        textColor: Colors.white,
      );

      // Navigate to dashboard
      if (mounted) {
        Navigator.pushReplacementNamed(context, '/dashboard');
      }
    } catch (e) {
      Fluttertoast.showToast(
        msg: "Biometric authentication failed. Please try password login.",
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
        textColor: Colors.white,
      );
    }
  }

  void _handleForgotPassword() {
    Fluttertoast.showToast(
      msg: "Password reset link will be sent to your email",
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _handleNeedHelp() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'IT Support',
          style: AppTheme.lightTheme.textTheme.titleLarge,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'For technical assistance, please contact:',
              style: AppTheme.lightTheme.textTheme.bodyMedium,
            ),
            SizedBox(height: 2.h),
            Row(
              children: [
                CustomIconWidget(
                  iconName: 'phone',
                  color: AppTheme.lightTheme.primaryColor,
                  size: 4.w,
                ),
                SizedBox(width: 2.w),
                Text(
                  '+1 (555) 123-4567',
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
            SizedBox(height: 1.h),
            Row(
              children: [
                CustomIconWidget(
                  iconName: 'email',
                  color: AppTheme.lightTheme.primaryColor,
                  size: 4.w,
                ),
                SizedBox(width: 2.w),
                Text(
                  'support@company.com',
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showOfflineMessage() {
    Fluttertoast.showToast(
      msg: "No internet connection. Please check your network and try again.",
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: AppTheme.getWarningColor(true),
      textColor: Colors.white,
    );
  }

  Future<void> _handleRetryConnection() async {
    await _checkConnectivity();
    if (!_isOffline) {
      Fluttertoast.showToast(
        msg: "Connection restored!",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: AppTheme.getSuccessColor(true),
        textColor: Colors.white,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: MediaQuery.of(context).size.height -
                    MediaQuery.of(context).padding.top -
                    MediaQuery.of(context).padding.bottom,
              ),
              child: Column(
                children: [
                  // Offline Indicator
                  OfflineIndicatorWidget(
                    isOffline: _isOffline,
                    onRetryPressed: _handleRetryConnection,
                  ),

                  SizedBox(height: 4.h),

                  // Company Logo
                  const CompanyLogoWidget(),

                  SizedBox(height: 4.h),

                  // Login Form
                  LoginFormWidget(
                    employeeIdController: _employeeIdController,
                    passwordController: _passwordController,
                    isLoading: _isLoading,
                    onLoginPressed: _handleLogin,
                    onForgotPasswordPressed: _handleForgotPassword,
                    employeeIdError: _employeeIdError,
                    passwordError: _passwordError,
                  ),

                  SizedBox(height: 3.h),

                  // Biometric Authentication
                  BiometricAuthWidget(
                    onBiometricPressed: _handleBiometricAuth,
                    isEnabled: _isBiometricEnabled && !_isLoading,
                  ),

                  SizedBox(height: 4.h),

                  // Help Section
                  HelpSectionWidget(
                    onNeedHelpPressed: _handleNeedHelp,
                  ),

                  SizedBox(height: 2.h),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
