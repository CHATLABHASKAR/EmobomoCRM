import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class BiometricAuthWidget extends StatelessWidget {
  final VoidCallback onBiometricPressed;
  final bool isEnabled;

  const BiometricAuthWidget({
    Key? key,
    required this.onBiometricPressed,
    this.isEnabled = true,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(vertical: 2.h),
      child: Column(
        children: [
          Container(
            width: 15.w,
            height: 15.w,
            decoration: BoxDecoration(
              color: isEnabled
                  ? AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1)
                  : AppTheme.lightTheme.colorScheme.surface
                      .withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(12.w),
              border: Border.all(
                color: isEnabled
                    ? AppTheme.lightTheme.primaryColor
                    : AppTheme.lightTheme.colorScheme.outline,
                width: 1.5,
              ),
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: isEnabled ? onBiometricPressed : null,
                borderRadius: BorderRadius.circular(12.w),
                child: Center(
                  child: CustomIconWidget(
                    iconName: 'fingerprint',
                    color: isEnabled
                        ? AppTheme.lightTheme.primaryColor
                        : AppTheme.lightTheme.colorScheme.outline,
                    size: 6.w,
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'Use Biometric',
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: isEnabled
                  ? AppTheme.lightTheme.primaryColor
                  : AppTheme.lightTheme.colorScheme.outline,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}
