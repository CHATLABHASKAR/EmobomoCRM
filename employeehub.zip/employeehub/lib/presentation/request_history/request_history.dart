import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/filter_bottom_sheet_widget.dart';
import './widgets/request_list_widget.dart';
import './widgets/search_bar_widget.dart';

class RequestHistory extends StatefulWidget {
  const RequestHistory({Key? key}) : super(key: key);

  @override
  State<RequestHistory> createState() => _RequestHistoryState();
}

class _RequestHistoryState extends State<RequestHistory>
    with TickerProviderStateMixin {
  late TabController _tabController;

  // State variables
  List<Map<String, dynamic>> _allRequests = [];
  List<Map<String, dynamic>> _filteredRequests = [];
  Map<String, dynamic> _currentFilters = {};
  String _searchQuery = '';
  bool _isLoading = false;
  bool _hasMore = true;
  int _currentPage = 1;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadMockData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _loadMockData() {
    // Mock data for requests
    _allRequests = [
      {
        "id": 1,
        "type": "vacation",
        "status": "approved",
        "startDate": "2025-07-25T00:00:00.000Z",
        "endDate": "2025-07-27T00:00:00.000Z",
        "submissionDate": "2025-07-15T10:30:00.000Z",
        "reason":
            "Family vacation to the beach. Need time to relax and spend quality time with family.",
        "manager": "John Smith",
        "days": 3,
        "comments": "Approved. Enjoy your vacation!"
      },
      {
        "id": 2,
        "type": "sick",
        "status": "pending",
        "startDate": "2025-07-20T00:00:00.000Z",
        "endDate": "2025-07-20T00:00:00.000Z",
        "submissionDate": "2025-07-18T08:15:00.000Z",
        "reason": "Feeling unwell with flu symptoms. Need rest to recover.",
        "manager": "Sarah Johnson",
        "days": 1,
        "comments": null
      },
      {
        "id": 3,
        "type": "wfh",
        "status": "approved",
        "startDate": "2025-07-22T00:00:00.000Z",
        "endDate": "2025-07-24T00:00:00.000Z",
        "submissionDate": "2025-07-16T14:20:00.000Z",
        "reason":
            "Home internet installation and setup. Need to be present for technician visit.",
        "manager": "Michael Brown",
        "days": 3,
        "comments": "Approved. Make sure to stay connected during work hours."
      },
      {
        "id": 4,
        "type": "personal",
        "status": "rejected",
        "startDate": "2025-07-19T00:00:00.000Z",
        "endDate": "2025-07-19T00:00:00.000Z",
        "submissionDate": "2025-07-17T16:45:00.000Z",
        "reason": "Personal appointment that cannot be rescheduled.",
        "manager": "Emily Davis",
        "days": 1,
        "comments":
            "Unfortunately, we have important client meetings scheduled. Please reschedule if possible."
      },
      {
        "id": 5,
        "type": "vacation",
        "status": "pending",
        "startDate": "2025-08-01T00:00:00.000Z",
        "endDate": "2025-08-05T00:00:00.000Z",
        "submissionDate": "2025-07-18T09:30:00.000Z",
        "reason":
            "Summer vacation with extended family. Annual family reunion.",
        "manager": "David Wilson",
        "days": 5,
        "comments": null
      },
      {
        "id": 6,
        "type": "wfh",
        "status": "approved",
        "startDate": "2025-07-21T00:00:00.000Z",
        "endDate": "2025-07-21T00:00:00.000Z",
        "submissionDate": "2025-07-14T11:00:00.000Z",
        "reason":
            "Avoiding traffic during city marathon event. Roads will be closed.",
        "manager": "John Smith",
        "days": 1,
        "comments": "Good thinking. Approved for WFH."
      },
      {
        "id": 7,
        "type": "sick",
        "status": "approved",
        "startDate": "2025-07-10T00:00:00.000Z",
        "endDate": "2025-07-12T00:00:00.000Z",
        "submissionDate": "2025-07-10T07:30:00.000Z",
        "reason":
            "Doctor recommended rest after minor surgery. Recovery period needed.",
        "manager": "Sarah Johnson",
        "days": 3,
        "comments": "Take care of yourself. Approved for recovery time."
      },
      {
        "id": 8,
        "type": "personal",
        "status": "approved",
        "startDate": "2025-07-08T00:00:00.000Z",
        "endDate": "2025-07-08T00:00:00.000Z",
        "submissionDate": "2025-07-05T13:15:00.000Z",
        "reason":
            "Attending graduation ceremony of my daughter. Important family milestone.",
        "manager": "Michael Brown",
        "days": 1,
        "comments": "Congratulations! Approved for this special occasion."
      }
    ];

    _applyFilters();
  }

  void _applyFilters() {
    setState(() {
      _filteredRequests = _allRequests.where((request) {
        // Apply search filter
        if (_searchQuery.isNotEmpty) {
          final reason = (request['reason'] ?? '').toString().toLowerCase();
          final startDate = request['startDate'] ?? '';
          final endDate = request['endDate'] ?? '';
          final searchLower = _searchQuery.toLowerCase();

          if (!reason.contains(searchLower) &&
              !startDate.contains(searchLower) &&
              !endDate.contains(searchLower)) {
            return false;
          }
        }

        // Apply status filter
        if (_currentFilters['status'] != null &&
            _currentFilters['status'] != 'All') {
          if (request['status']?.toLowerCase() !=
              _currentFilters['status']?.toLowerCase()) {
            return false;
          }
        }

        // Apply type filter
        if (_currentFilters['type'] != null &&
            _currentFilters['type'] != 'All') {
          if (request['type']?.toLowerCase() !=
              _currentFilters['type']?.toLowerCase()) {
            return false;
          }
        }

        // Apply manager filter
        if (_currentFilters['manager'] != null &&
            _currentFilters['manager'] != 'All Managers') {
          if (request['manager'] != _currentFilters['manager']) {
            return false;
          }
        }

        // Apply date range filter
        if (_currentFilters['startDate'] != null &&
            _currentFilters['endDate'] != null) {
          final requestStart = DateTime.parse(request['startDate']);
          final filterStart = DateTime.parse(_currentFilters['startDate']);
          final filterEnd = DateTime.parse(_currentFilters['endDate']);

          if (requestStart.isBefore(filterStart) ||
              requestStart.isAfter(filterEnd)) {
            return false;
          }
        }

        return true;
      }).toList();

      // Sort by submission date (newest first)
      _filteredRequests.sort((a, b) {
        final dateA = DateTime.parse(a['submissionDate']);
        final dateB = DateTime.parse(b['submissionDate']);
        return dateB.compareTo(dateA);
      });
    });
  }

  List<Map<String, dynamic>> _getRequestsByType(String type) {
    if (type == 'all') return _filteredRequests;

    return _filteredRequests.where((request) {
      if (type == 'leave') {
        return ['sick', 'vacation', 'personal'].contains(request['type']);
      } else if (type == 'wfh') {
        return request['type'] == 'wfh';
      }
      return false;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          _buildSearchSection(),
          _buildTabBar(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildRequestList('leave'),
                _buildRequestList('wfh'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: const Text('Request History'),
      leading: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Padding(
          padding: EdgeInsets.all(3.w),
          child: CustomIconWidget(
            iconName: 'arrow_back',
            color: AppTheme.lightTheme.colorScheme.onSurface,
            size: 6.w,
          ),
        ),
      ),
      actions: [
        GestureDetector(
          onTap: _showFilterBottomSheet,
          child: Padding(
            padding: EdgeInsets.all(3.w),
            child: CustomIconWidget(
              iconName: 'filter_list',
              color: AppTheme.lightTheme.colorScheme.onSurface,
              size: 6.w,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSearchSection() {
    return SearchBarWidget(
      initialValue: _searchQuery,
      onSearchChanged: (query) {
        setState(() {
          _searchQuery = query;
        });
        _applyFilters();
      },
      onFilterTap: _showFilterBottomSheet,
    );
  }

  Widget _buildTabBar() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color:
                AppTheme.lightTheme.colorScheme.shadow.withValues(alpha: 0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.primary,
          borderRadius: BorderRadius.circular(12),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        labelColor: AppTheme.lightTheme.colorScheme.onPrimary,
        unselectedLabelColor: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
        tabs: [
          Tab(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomIconWidget(
                  iconName: 'event_note',
                  color: _tabController.index == 0
                      ? AppTheme.lightTheme.colorScheme.onPrimary
                      : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  size: 5.w,
                ),
                SizedBox(width: 2.w),
                const Text('Leave'),
              ],
            ),
          ),
          Tab(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomIconWidget(
                  iconName: 'home_work',
                  color: _tabController.index == 1
                      ? AppTheme.lightTheme.colorScheme.onPrimary
                      : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  size: 5.w,
                ),
                SizedBox(width: 2.w),
                const Text('WFH'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRequestList(String type) {
    final requests = _getRequestsByType(type);

    return RequestListWidget(
      requests: requests,
      isLoading: _isLoading,
      hasMore: _hasMore,
      onLoadMore: _loadMoreRequests,
      onRefresh: _refreshRequests,
      onRequestTap: _navigateToRequestDetails,
      onRequestCancel: _cancelRequest,
      onRequestResubmit: _resubmitRequest,
      onRequestDelete: _deleteRequest,
      onSubmitRequest: _navigateToSubmitRequest,
    );
  }

  void _showFilterBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => FilterBottomSheetWidget(
        currentFilters: _currentFilters,
        onFiltersApplied: (filters) {
          setState(() {
            _currentFilters = filters;
          });
          _applyFilters();
        },
      ),
    );
  }

  void _loadMoreRequests() {
    if (_isLoading || !_hasMore) return;

    setState(() {
      _isLoading = true;
    });

    // Simulate loading more data
    Future.delayed(const Duration(seconds: 1), () {
      setState(() {
        _isLoading = false;
        _currentPage++;
        // For demo purposes, stop loading after page 3
        if (_currentPage >= 3) {
          _hasMore = false;
        }
      });
    });
  }

  void _refreshRequests() {
    setState(() {
      _isLoading = true;
      _currentPage = 1;
      _hasMore = true;
    });

    // Simulate refresh
    Future.delayed(const Duration(seconds: 1), () {
      setState(() {
        _isLoading = false;
      });
      _loadMockData();
    });
  }

  void _navigateToRequestDetails(Map<String, dynamic> request) {
    // Navigate to request details screen
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Request Details'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Type: ${_getRequestTitle(request['type'])}'),
            Text('Status: ${request['status']}'),
            Text('Dates: ${_formatDateRange(request)}'),
            if (request['reason'] != null) Text('Reason: ${request['reason']}'),
            if (request['comments'] != null)
              Text('Comments: ${request['comments']}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _cancelRequest(Map<String, dynamic> request) {
    setState(() {
      final index = _allRequests.indexWhere((r) => r['id'] == request['id']);
      if (index != -1) {
        _allRequests[index]['status'] = 'cancelled';
      }
    });
    _applyFilters();

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Request cancelled successfully')),
    );
  }

  void _resubmitRequest(Map<String, dynamic> request) {
    Navigator.pushNamed(context, '/leave-request');
  }

  void _deleteRequest(Map<String, dynamic> request) {
    setState(() {
      _allRequests.removeWhere((r) => r['id'] == request['id']);
    });
    _applyFilters();

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Request deleted successfully')),
    );
  }

  void _navigateToSubmitRequest() {
    Navigator.pushNamed(context, '/leave-request');
  }

  String _getRequestTitle(String? type) {
    switch (type?.toLowerCase()) {
      case 'wfh':
      case 'work_from_home':
        return 'Work From Home';
      case 'sick':
        return 'Sick Leave';
      case 'vacation':
        return 'Vacation Leave';
      case 'personal':
        return 'Personal Leave';
      default:
        return 'Leave Request';
    }
  }

  String _formatDateRange(Map<String, dynamic> request) {
    final start = DateTime.parse(request['startDate']);
    final end = DateTime.parse(request['endDate']);

    if (start.day == end.day &&
        start.month == end.month &&
        start.year == end.year) {
      return '${start.month}/${start.day}/${start.year}';
    }
    return '${start.month}/${start.day}/${start.year} - ${end.month}/${end.day}/${end.year}';
  }
}
