import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class RequestCardWidget extends StatelessWidget {
  final Map<String, dynamic> request;
  final VoidCallback? onTap;
  final VoidCallback? onViewDetails;
  final VoidCallback? onCancel;
  final VoidCallback? onResubmit;
  final VoidCallback? onDelete;

  const RequestCardWidget({
    Key? key,
    required this.request,
    this.onTap,
    this.onViewDetails,
    this.onCancel,
    this.onResubmit,
    this.onDelete,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final String status = request['status'] ?? 'pending';
    final String type = request['type'] ?? 'leave';
    final DateTime startDate =
        DateTime.parse(request['startDate'] ?? DateTime.now().toString());
    final DateTime endDate =
        DateTime.parse(request['endDate'] ?? DateTime.now().toString());
    final DateTime submissionDate =
        DateTime.parse(request['submissionDate'] ?? DateTime.now().toString());

    return Dismissible(
      key: Key(request['id'].toString()),
      background: _buildSwipeBackground(context, isLeft: true),
      secondaryBackground: _buildSwipeBackground(context, isLeft: false),
      onDismissed: (direction) {
        if (direction == DismissDirection.startToEnd) {
          // Swipe right - show actions
          _showQuickActions(context);
        } else {
          // Swipe left - delete
          onDelete?.call();
        }
      },
      confirmDismiss: (direction) async {
        if (direction == DismissDirection.startToEnd) {
          _showQuickActions(context);
          return false;
        }
        return true;
      },
      child: GestureDetector(
        onTap: onTap,
        onLongPress: () => _showContextMenu(context),
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          decoration: BoxDecoration(
            color: AppTheme.lightTheme.colorScheme.surface,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: AppTheme.lightTheme.colorScheme.shadow
                    .withValues(alpha: 0.1),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Padding(
            padding: EdgeInsets.all(4.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    _buildTypeIcon(type),
                    SizedBox(width: 3.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _getRequestTitle(type),
                            style: AppTheme.lightTheme.textTheme.titleMedium,
                          ),
                          SizedBox(height: 0.5.h),
                          Text(
                            _formatDateRange(startDate, endDate),
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    ),
                    _buildStatusBadge(status),
                  ],
                ),
                SizedBox(height: 2.h),
                if (request['reason'] != null) ...[
                  Text(
                    request['reason'],
                    style: AppTheme.lightTheme.textTheme.bodyMedium,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 1.h),
                ],
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Submitted: ${_formatSubmissionDate(submissionDate)}',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    if (request['manager'] != null)
                      Text(
                        'Manager: ${request['manager']}',
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTypeIcon(String type) {
    String iconName;
    Color iconColor;

    switch (type.toLowerCase()) {
      case 'wfh':
      case 'work_from_home':
        iconName = 'home_work';
        iconColor = AppTheme.lightTheme.colorScheme.tertiary;
        break;
      case 'sick':
        iconName = 'local_hospital';
        iconColor = AppTheme.errorLight;
        break;
      case 'vacation':
        iconName = 'beach_access';
        iconColor = AppTheme.successLight;
        break;
      case 'personal':
        iconName = 'person';
        iconColor = AppTheme.warningLight;
        break;
      default:
        iconName = 'event_note';
        iconColor = AppTheme.lightTheme.colorScheme.primary;
    }

    return Container(
      padding: EdgeInsets.all(2.w),
      decoration: BoxDecoration(
        color: iconColor.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: CustomIconWidget(
        iconName: iconName,
        color: iconColor,
        size: 6.w,
      ),
    );
  }

  Widget _buildStatusBadge(String status) {
    Color backgroundColor;
    Color textColor;
    String displayText;

    switch (status.toLowerCase()) {
      case 'approved':
        backgroundColor = AppTheme.successLight;
        textColor = Colors.white;
        displayText = 'Approved';
        break;
      case 'rejected':
        backgroundColor = AppTheme.errorLight;
        textColor = Colors.white;
        displayText = 'Rejected';
        break;
      case 'pending':
      default:
        backgroundColor = AppTheme.warningLight;
        textColor = Colors.white;
        displayText = 'Pending';
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Text(
        displayText,
        style: AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
          color: textColor,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildSwipeBackground(BuildContext context, {required bool isLeft}) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: isLeft
            ? AppTheme.lightTheme.colorScheme.primary
            : AppTheme.errorLight,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Align(
        alignment: isLeft ? Alignment.centerLeft : Alignment.centerRight,
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 6.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomIconWidget(
                iconName: isLeft ? 'more_horiz' : 'delete',
                color: Colors.white,
                size: 6.w,
              ),
              SizedBox(height: 0.5.h),
              Text(
                isLeft ? 'Actions' : 'Delete',
                style: AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showQuickActions(BuildContext context) {
    final String status = request['status'] ?? 'pending';

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 3.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'visibility',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 6.w,
              ),
              title: const Text('View Details'),
              onTap: () {
                Navigator.pop(context);
                onViewDetails?.call();
              },
            ),
            if (status.toLowerCase() == 'pending') ...[
              ListTile(
                leading: CustomIconWidget(
                  iconName: 'cancel',
                  color: AppTheme.errorLight,
                  size: 6.w,
                ),
                title: const Text('Cancel Request'),
                onTap: () {
                  Navigator.pop(context);
                  onCancel?.call();
                },
              ),
            ],
            if (status.toLowerCase() == 'rejected') ...[
              ListTile(
                leading: CustomIconWidget(
                  iconName: 'refresh',
                  color: AppTheme.successLight,
                  size: 6.w,
                ),
                title: const Text('Resubmit Request'),
                onTap: () {
                  Navigator.pop(context);
                  onResubmit?.call();
                },
              ),
            ],
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  void _showContextMenu(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 3.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'share',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 6.w,
              ),
              title: const Text('Share'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'download',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 6.w,
              ),
              title: const Text('Export'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'content_copy',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 6.w,
              ),
              title: const Text('Duplicate'),
              onTap: () => Navigator.pop(context),
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  String _getRequestTitle(String type) {
    switch (type.toLowerCase()) {
      case 'wfh':
      case 'work_from_home':
        return 'Work From Home';
      case 'sick':
        return 'Sick Leave';
      case 'vacation':
        return 'Vacation Leave';
      case 'personal':
        return 'Personal Leave';
      default:
        return 'Leave Request';
    }
  }

  String _formatDateRange(DateTime start, DateTime end) {
    if (start.day == end.day &&
        start.month == end.month &&
        start.year == end.year) {
      return '${start.month}/${start.day}/${start.year}';
    }
    return '${start.month}/${start.day}/${start.year} - ${end.month}/${end.day}/${end.year}';
  }

  String _formatSubmissionDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays == 0) {
      return 'Today';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return '${date.month}/${date.day}/${date.year}';
    }
  }
}
