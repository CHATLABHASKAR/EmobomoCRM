import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/attachment_section.dart';
import './widgets/date_range_picker.dart';
import './widgets/half_day_toggle.dart';
import './widgets/leave_balance_card.dart';
import './widgets/leave_type_selector.dart';
import './widgets/manager_assignment.dart';

class LeaveRequest extends StatefulWidget {
  const LeaveRequest({Key? key}) : super(key: key);

  @override
  State<LeaveRequest> createState() => _LeaveRequestState();
}

class _LeaveRequestState extends State<LeaveRequest> {
  final _formKey = GlobalKey<FormState>();
  final _reasonController = TextEditingController();

  String _selectedLeaveType = 'Vacation';
  DateTime? _startDate;
  DateTime? _endDate;
  bool _isHalfDay = false;
  String _halfDayPeriod = 'morning';
  String _selectedManager = 'sarah_johnson';
  List<Map<String, dynamic>> _attachments = [];
  bool _isSubmitting = false;

  @override
  void dispose() {
    _reasonController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text('Leave Request'),
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            color: AppTheme.lightTheme.colorScheme.onSurface,
            size: 24,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
        ],
      ),
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            padding: EdgeInsets.all(4.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Leave Type Selector
                LeaveTypeSelector(
                  selectedType: _selectedLeaveType,
                  onTypeSelected: (type) {
                    setState(() {
                      _selectedLeaveType = type;
                    });
                  },
                ),

                SizedBox(height: 4.h),

                // Date Range Picker
                DateRangePicker(
                  startDate: _startDate,
                  endDate: _endDate,
                  onDateRangeSelected: (start, end) {
                    setState(() {
                      _startDate = start;
                      _endDate = end;
                    });
                  },
                ),

                SizedBox(height: 4.h),

                // Half Day Toggle
                HalfDayToggle(
                  isHalfDay: _isHalfDay,
                  halfDayPeriod: _halfDayPeriod,
                  onHalfDayToggle: (value) {
                    setState(() {
                      _isHalfDay = value;
                    });
                  },
                  onPeriodChanged: (period) {
                    setState(() {
                      _halfDayPeriod = period;
                    });
                  },
                ),

                SizedBox(height: 4.h),

                // Reason Text Field
                _buildReasonField(),

                SizedBox(height: 4.h),

                // Leave Balance Card
                if (_startDate != null && _endDate != null)
                  LeaveBalanceCard(
                    leaveType: _selectedLeaveType,
                    requestedDays: _calculateRequestedDays(),
                  ),

                SizedBox(height: 4.h),

                // Attachment Section
                AttachmentSection(
                  attachments: _attachments,
                  onAttachmentAdded: (attachment) {
                    setState(() {
                      _attachments.add(attachment);
                    });
                  },
                  onAttachmentRemoved: (index) {
                    setState(() {
                      _attachments.removeAt(index);
                    });
                  },
                ),

                SizedBox(height: 4.h),

                // Manager Assignment
                ManagerAssignment(
                  selectedManager: _selectedManager,
                  onManagerChanged: (managerId) {
                    setState(() {
                      _selectedManager = managerId;
                    });
                  },
                ),

                SizedBox(height: 6.h),

                // Submit Button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _canSubmit() ? _submitRequest : null,
                    child: _isSubmitting
                        ? Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    AppTheme.lightTheme.colorScheme.onPrimary,
                                  ),
                                ),
                              ),
                              SizedBox(width: 3.w),
                              Text('Submitting Request...'),
                            ],
                          )
                        : Text('Submit Leave Request'),
                  ),
                ),

                SizedBox(height: 2.h),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildReasonField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Reason for Leave',
          style: AppTheme.lightTheme.textTheme.titleMedium,
        ),
        SizedBox(height: 2.h),
        TextFormField(
          controller: _reasonController,
          maxLines: 4,
          maxLength: 500,
          decoration: InputDecoration(
            hintText: 'Please provide a reason for your leave request...',
            counterText: '${_reasonController.text.length}/500',
          ),
          validator: (value) {
            if (value == null || value.trim().isEmpty) {
              return 'Please provide a reason for your leave request';
            }
            if (value.trim().length < 10) {
              return 'Reason must be at least 10 characters long';
            }
            return null;
          },
          onChanged: (value) {
            setState(() {}); // Update character counter
          },
        ),
      ],
    );
  }

  bool _canSubmit() {
    return _startDate != null &&
        _endDate != null &&
        _reasonController.text.trim().length >= 10 &&
        !_isSubmitting &&
        _calculateRequestedDays() > 0;
  }

  int _calculateRequestedDays() {
    if (_startDate == null || _endDate == null) return 0;

    int days = _endDate!.difference(_startDate!).inDays + 1;

    // Adjust for half day
    if (_isHalfDay && days == 1) {
      return 1; // Half day still counts as 1 day for balance calculation
    }

    return days;
  }

  Future<void> _submitRequest() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isSubmitting = true;
    });

    try {
      // Simulate API call
      await Future.delayed(Duration(seconds: 2));

      // Generate mock request ID
      final requestId =
          'LR${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}';

      // Show success dialog
      _showSuccessDialog(requestId);
    } catch (e) {
      // Show error message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to submit leave request. Please try again.'),
          backgroundColor: AppTheme.lightTheme.colorScheme.error,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isSubmitting = false;
        });
      }
    }
  }

  void _showSuccessDialog(String requestId) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: AppTheme.getSuccessColor(true).withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: CustomIconWidget(
                iconName: 'check_circle',
                color: AppTheme.getSuccessColor(true),
                size: 48,
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Request Submitted Successfully!',
              style: AppTheme.lightTheme.textTheme.titleLarge,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 2.h),
            Text(
              'Your leave request has been submitted with ID: $requestId',
              style: AppTheme.lightTheme.textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 1.h),
            Text(
              'Expected approval within 2-3 business days.',
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 4.h),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.pop(context); // Close dialog
                      Navigator.pushNamed(context, '/request-history');
                    },
                    child: Text('View Requests'),
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context); // Close dialog
                      Navigator.pop(context); // Go back to previous screen
                    },
                    child: Text('Done'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
