import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';

class HalfDayToggle extends StatelessWidget {
  final bool isHalfDay;
  final String halfDayPeriod;
  final Function(bool) onHalfDayToggle;
  final Function(String) onPeriodChanged;

  const HalfDayToggle({
    Key? key,
    required this.isHalfDay,
    required this.halfDayPeriod,
    required this.onHalfDayToggle,
    required this.onPeriodChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Half Day Request',
              style: AppTheme.lightTheme.textTheme.titleMedium,
            ),
            Switch(
              value: isHalfDay,
              onChanged: onHalfDayToggle,
            ),
          ],
        ),
        if (isHalfDay) ...[
          SizedBox(height: 2.h),
          Text(
            'Select Period',
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 1.h),
          Row(
            children: [
              Expanded(
                child: _buildPeriodOption(
                  'Morning',
                  'morning',
                  '9:00 AM - 1:00 PM',
                  'wb_sunny',
                ),
              ),
              SizedBox(width: 4.w),
              Expanded(
                child: _buildPeriodOption(
                  'Afternoon',
                  'afternoon',
                  '1:00 PM - 6:00 PM',
                  'brightness_3',
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }

  Widget _buildPeriodOption(
    String title,
    String value,
    String timeRange,
    String iconName,
  ) {
    final isSelected = halfDayPeriod == value;

    return GestureDetector(
      onTap: () => onPeriodChanged(value),
      child: Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1)
              : AppTheme.lightTheme.colorScheme.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected
                ? AppTheme.lightTheme.colorScheme.primary
                : AppTheme.lightTheme.colorScheme.outline,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Column(
          children: [
            CustomIconWidget(
              iconName: iconName,
              color: isSelected
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 32,
            ),
            SizedBox(height: 1.h),
            Text(
              title,
              style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                color: isSelected
                    ? AppTheme.lightTheme.colorScheme.primary
                    : AppTheme.lightTheme.colorScheme.onSurface,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
              ),
            ),
            SizedBox(height: 0.5.h),
            Text(
              timeRange,
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: isSelected
                    ? AppTheme.lightTheme.colorScheme.primary
                    : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
