import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';

class ManagerAssignment extends StatelessWidget {
  final String selectedManager;
  final Function(String) onManagerChanged;

  const ManagerAssignment({
    Key? key,
    required this.selectedManager,
    required this.onManagerChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final managers = [
      {
        'id': 'sarah_johnson',
        'name': 'Sarah Johnson',
        'title': 'HR Manager',
        'avatar':
            'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
        'department': 'Human Resources'
      },
      {
        'id': 'michael_chen',
        'name': 'Michael Chen',
        'title': 'Team Lead',
        'avatar':
            'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
        'department': 'Engineering'
      },
      {
        'id': 'emily_davis',
        'name': 'Emily Davis',
        'title': 'Department Head',
        'avatar':
            'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
        'department': 'Operations'
      },
    ];

    final currentManager = managers.firstWhere(
      (manager) => manager['id'] == selectedManager,
      orElse: () => managers.first,
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Approving Manager',
          style: AppTheme.lightTheme.textTheme.titleMedium,
        ),
        SizedBox(height: 2.h),
        GestureDetector(
          onTap: () => _showManagerSelection(context, managers),
          child: Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline,
              ),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 24,
                  backgroundColor: AppTheme.lightTheme.colorScheme.primary
                      .withValues(alpha: 0.1),
                  child: ClipOval(
                    child: CustomImageWidget(
                      imageUrl: currentManager['avatar'] as String,
                      width: 48,
                      height: 48,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(width: 4.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        currentManager['name'] as String,
                        style: AppTheme.lightTheme.textTheme.titleSmall,
                      ),
                      SizedBox(height: 0.5.h),
                      Text(
                        currentManager['title'] as String,
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                      Text(
                        currentManager['department'] as String,
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                CustomIconWidget(
                  iconName: 'keyboard_arrow_down',
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  size: 24,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  void _showManagerSelection(
      BuildContext context, List<Map<String, dynamic>> managers) {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Container(
          padding: EdgeInsets.all(4.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              SizedBox(height: 3.h),
              Text(
                'Select Approving Manager',
                style: AppTheme.lightTheme.textTheme.titleLarge,
              ),
              SizedBox(height: 3.h),
              ListView.separated(
                shrinkWrap: true,
                itemCount: managers.length,
                separatorBuilder: (context, index) => SizedBox(height: 2.h),
                itemBuilder: (context, index) {
                  final manager = managers[index];
                  final isSelected = selectedManager == manager['id'];

                  return ListTile(
                    leading: CircleAvatar(
                      radius: 20,
                      backgroundColor: AppTheme.lightTheme.colorScheme.primary
                          .withValues(alpha: 0.1),
                      child: ClipOval(
                        child: CustomImageWidget(
                          imageUrl: manager['avatar'] as String,
                          width: 40,
                          height: 40,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    title: Text(
                      manager['name'] as String,
                      style: AppTheme.lightTheme.textTheme.titleSmall,
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(manager['title'] as String),
                        Text(manager['department'] as String),
                      ],
                    ),
                    trailing: isSelected
                        ? CustomIconWidget(
                            iconName: 'check_circle',
                            color: AppTheme.lightTheme.colorScheme.primary,
                            size: 24,
                          )
                        : null,
                    onTap: () {
                      onManagerChanged(manager['id'] as String);
                      Navigator.pop(context);
                    },
                  );
                },
              ),
              SizedBox(height: 3.h),
            ],
          ),
        );
      },
    );
  }
}
