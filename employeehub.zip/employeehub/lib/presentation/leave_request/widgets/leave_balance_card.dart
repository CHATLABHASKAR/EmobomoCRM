import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';

class LeaveBalanceCard extends StatelessWidget {
  final String leaveType;
  final int requestedDays;

  const LeaveBalanceCard({
    Key? key,
    required this.leaveType,
    required this.requestedDays,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final balanceData = _getLeaveBalance(leaveType);
    final remainingDays = (balanceData['available'] as int) - requestedDays;

    return Card(
      elevation: 2,
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CustomIconWidget(
                  iconName: 'account_balance_wallet',
                  color: AppTheme.lightTheme.colorScheme.primary,
                  size: 24,
                ),
                SizedBox(width: 3.w),
                Text(
                  '$leaveType Leave Balance',
                  style: AppTheme.lightTheme.textTheme.titleMedium,
                ),
              ],
            ),
            SizedBox(height: 3.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildBalanceItem(
                  'Total Allocated',
                  balanceData['total'].toString(),
                  AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
                _buildBalanceItem(
                  'Used',
                  balanceData['used'].toString(),
                  AppTheme.getWarningColor(true),
                ),
                _buildBalanceItem(
                  'Available',
                  balanceData['available'].toString(),
                  AppTheme.getSuccessColor(true),
                ),
              ],
            ),
            if (requestedDays > 0) ...[
              SizedBox(height: 3.h),
              Divider(color: AppTheme.lightTheme.colorScheme.outline),
              SizedBox(height: 2.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Requested Days:',
                    style: AppTheme.lightTheme.textTheme.bodyMedium,
                  ),
                  Text(
                    requestedDays.toString(),
                    style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: AppTheme.lightTheme.colorScheme.primary,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 1.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Remaining After Request:',
                    style: AppTheme.lightTheme.textTheme.bodyMedium,
                  ),
                  Text(
                    remainingDays.toString(),
                    style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: remainingDays >= 0
                          ? AppTheme.getSuccessColor(true)
                          : AppTheme.lightTheme.colorScheme.error,
                    ),
                  ),
                ],
              ),
              if (remainingDays < 0) ...[
                SizedBox(height: 2.h),
                Container(
                  padding: EdgeInsets.all(3.w),
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.error
                        .withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'warning',
                        color: AppTheme.lightTheme.colorScheme.error,
                        size: 20,
                      ),
                      SizedBox(width: 2.w),
                      Expanded(
                        child: Text(
                          'Insufficient leave balance. Request exceeds available days.',
                          style:
                              AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.lightTheme.colorScheme.error,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildBalanceItem(String label, String value, Color color) {
    return Column(
      children: [
        Text(
          value,
          style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
            color: color,
            fontWeight: FontWeight.w700,
          ),
        ),
        SizedBox(height: 0.5.h),
        Text(
          label,
          style: AppTheme.lightTheme.textTheme.bodySmall,
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Map<String, int> _getLeaveBalance(String type) {
    // Mock data for leave balances
    final balances = {
      'Vacation': {'total': 20, 'used': 8, 'available': 12},
      'Sick': {'total': 10, 'used': 3, 'available': 7},
      'Personal': {'total': 5, 'used': 1, 'available': 4},
      'Emergency': {'total': 3, 'used': 0, 'available': 3},
    };

    return balances[type] ?? {'total': 0, 'used': 0, 'available': 0};
  }
}
