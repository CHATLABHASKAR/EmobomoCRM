import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';

class LeaveTypeSelector extends StatelessWidget {
  final String selectedType;
  final Function(String) onTypeSelected;

  const LeaveTypeSelector({
    Key? key,
    required this.selectedType,
    required this.onTypeSelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final leaveTypes = [
      {
        'name': 'Vacation',
        'icon': 'beach_access',
        'color': AppTheme.lightTheme.colorScheme.primary
      },
      {
        'name': 'Sick',
        'icon': 'local_hospital',
        'color': AppTheme.getWarningColor(true)
      },
      {
        'name': 'Personal',
        'icon': 'person',
        'color': AppTheme.getAccentColor(true)
      },
      {
        'name': 'Emergency',
        'icon': 'emergency',
        'color': AppTheme.lightTheme.colorScheme.error
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Leave Type',
          style: AppTheme.lightTheme.textTheme.titleMedium,
        ),
        SizedBox(height: 2.h),
        SizedBox(
          height: 6.h,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: leaveTypes.length,
            separatorBuilder: (context, index) => SizedBox(width: 3.w),
            itemBuilder: (context, index) {
              final type = leaveTypes[index];
              final isSelected = selectedType == type['name'];

              return GestureDetector(
                onTap: () => onTypeSelected(type['name'] as String),
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? (type['color'] as Color).withValues(alpha: 0.1)
                        : AppTheme.lightTheme.colorScheme.surface,
                    borderRadius: BorderRadius.circular(25),
                    border: Border.all(
                      color: isSelected
                          ? (type['color'] as Color)
                          : AppTheme.lightTheme.colorScheme.outline,
                      width: isSelected ? 2 : 1,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CustomIconWidget(
                        iconName: type['icon'] as String,
                        color: isSelected
                            ? (type['color'] as Color)
                            : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        size: 20,
                      ),
                      SizedBox(width: 2.w),
                      Text(
                        type['name'] as String,
                        style:
                            AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
                          color: isSelected
                              ? (type['color'] as Color)
                              : AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                          fontWeight:
                              isSelected ? FontWeight.w600 : FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
