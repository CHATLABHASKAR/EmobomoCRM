import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';

class AttachmentSection extends StatelessWidget {
  final List<Map<String, dynamic>> attachments;
  final Function(Map<String, dynamic>) onAttachmentAdded;
  final Function(int) onAttachmentRemoved;

  const AttachmentSection({
    Key? key,
    required this.attachments,
    required this.onAttachmentAdded,
    required this.onAttachmentRemoved,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Attachments (Optional)',
          style: AppTheme.lightTheme.textTheme.titleMedium,
        ),
        SizedBox(height: 2.h),
        OutlinedButton.icon(
          onPressed: () => _selectFile(context),
          icon: CustomIconWidget(
            iconName: 'attach_file',
            color: AppTheme.lightTheme.colorScheme.primary,
            size: 20,
          ),
          label: Text('Add Attachment'),
          style: OutlinedButton.styleFrom(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
          ),
        ),
        if (attachments.isNotEmpty) ...[
          SizedBox(height: 3.h),
          ListView.separated(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemCount: attachments.length,
            separatorBuilder: (context, index) => SizedBox(height: 2.h),
            itemBuilder: (context, index) {
              final attachment = attachments[index];
              return _buildAttachmentTile(attachment, index);
            },
          ),
        ],
      ],
    );
  }

  Widget _buildAttachmentTile(Map<String, dynamic> attachment, int index) {
    final fileName = attachment['name'] as String;
    final fileSize = attachment['size'] as String;
    final fileType = _getFileType(fileName);

    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: _getFileTypeColor(fileType).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: CustomIconWidget(
              iconName: _getFileTypeIcon(fileType),
              color: _getFileTypeColor(fileType),
              size: 24,
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  fileName,
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                SizedBox(height: 0.5.h),
                Text(
                  fileSize,
                  style: AppTheme.lightTheme.textTheme.bodySmall,
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: () => onAttachmentRemoved(index),
            icon: CustomIconWidget(
              iconName: 'close',
              color: AppTheme.lightTheme.colorScheme.error,
              size: 20,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _selectFile(BuildContext context) async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'],
        allowMultiple: false,
      );

      if (result != null && result.files.isNotEmpty) {
        final file = result.files.first;
        final attachment = {
          'name': file.name,
          'size': _formatFileSize(file.size),
          'bytes': kIsWeb ? file.bytes : null,
          'path': !kIsWeb ? file.path : null,
        };

        onAttachmentAdded(attachment);
      }
    } catch (e) {
      // Handle error silently or show user-friendly message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to select file. Please try again.'),
          backgroundColor: AppTheme.lightTheme.colorScheme.error,
        ),
      );
    }
  }

  String _getFileType(String fileName) {
    final extension = fileName.split('.').last.toLowerCase();
    switch (extension) {
      case 'pdf':
        return 'pdf';
      case 'doc':
      case 'docx':
        return 'document';
      case 'jpg':
      case 'jpeg':
      case 'png':
        return 'image';
      default:
        return 'file';
    }
  }

  String _getFileTypeIcon(String fileType) {
    switch (fileType) {
      case 'pdf':
        return 'picture_as_pdf';
      case 'document':
        return 'description';
      case 'image':
        return 'image';
      default:
        return 'insert_drive_file';
    }
  }

  Color _getFileTypeColor(String fileType) {
    switch (fileType) {
      case 'pdf':
        return AppTheme.lightTheme.colorScheme.error;
      case 'document':
        return AppTheme.lightTheme.colorScheme.primary;
      case 'image':
        return AppTheme.getSuccessColor(true);
      default:
        return AppTheme.lightTheme.colorScheme.onSurfaceVariant;
    }
  }

  String _formatFileSize(int bytes) {
    if (bytes < 1024) return '${bytes} B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
}
