import 'dart:convert';
import 'dart:html' as html if (dart.library.html) 'dart:html';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/analytics_summary_widget.dart';
import './widgets/attendance_card_widget.dart';
import './widgets/calendar_widget.dart';
import './widgets/filter_bottom_sheet_widget.dart';

class AttendanceHistory extends StatefulWidget {
  const AttendanceHistory({Key? key}) : super(key: key);

  @override
  State<AttendanceHistory> createState() => _AttendanceHistoryState();
}

class _AttendanceHistoryState extends State<AttendanceHistory>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  DateTime _selectedDate = DateTime.now();
  Map<String, dynamic> _currentFilters = {};
  bool _isLoading = false;
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();

  // Mock attendance data
  final List<Map<String, dynamic>> _attendanceHistory = [
    {
      "date": "2025-01-18",
      "status": "present",
      "checkIn": "09:15",
      "checkOut": "18:30",
      "totalHours": "8h 15m",
      "location": "Office Building A, Floor 3",
      "isLocationVerified": true,
      "breakTime": "1h 0m",
      "overtime": "0h 30m",
      "accuracy": "±3 meters"
    },
    {
      "date": "2025-01-17",
      "status": "present",
      "checkIn": "09:00",
      "checkOut": "18:00",
      "totalHours": "8h 0m",
      "location": "Office Building A, Floor 3",
      "isLocationVerified": true,
      "breakTime": "1h 0m",
      "overtime": "0h 0m",
      "accuracy": "±5 meters"
    },
    {
      "date": "2025-01-16",
      "status": "wfh",
      "checkIn": "09:30",
      "checkOut": "17:45",
      "totalHours": "7h 15m",
      "location": "Home Office - Remote",
      "isLocationVerified": false,
      "breakTime": "1h 0m",
      "overtime": "0h 0m",
      "accuracy": "N/A"
    },
    {
      "date": "2025-01-15",
      "status": "present",
      "checkIn": "08:45",
      "checkOut": "18:15",
      "totalHours": "8h 30m",
      "location": "Office Building A, Floor 3",
      "isLocationVerified": true,
      "breakTime": "1h 0m",
      "overtime": "0h 30m",
      "accuracy": "±2 meters"
    },
    {
      "date": "2025-01-14",
      "status": "absent",
      "checkIn": null,
      "checkOut": null,
      "totalHours": "0h 0m",
      "location": null,
      "isLocationVerified": false,
      "breakTime": "0h 0m",
      "overtime": "0h 0m",
      "accuracy": "N/A"
    },
    {
      "date": "2025-01-13",
      "status": "present",
      "checkIn": "09:10",
      "checkOut": "18:20",
      "totalHours": "8h 10m",
      "location": "Office Building A, Floor 3",
      "isLocationVerified": true,
      "breakTime": "1h 0m",
      "overtime": "0h 20m",
      "accuracy": "±4 meters"
    },
    {
      "date": "2025-01-12",
      "status": "holiday",
      "checkIn": null,
      "checkOut": null,
      "totalHours": "0h 0m",
      "location": null,
      "isLocationVerified": false,
      "breakTime": "0h 0m",
      "overtime": "0h 0m",
      "accuracy": "N/A"
    },
    {
      "date": "2025-01-11",
      "status": "present",
      "checkIn": "09:05",
      "checkOut": "18:10",
      "totalHours": "8h 5m",
      "location": "Office Building A, Floor 3",
      "isLocationVerified": true,
      "breakTime": "1h 0m",
      "overtime": "0h 10m",
      "accuracy": "±6 meters"
    },
    {
      "date": "2025-01-10",
      "status": "wfh",
      "checkIn": "09:20",
      "checkOut": "17:30",
      "totalHours": "7h 10m",
      "location": "Home Office - Remote",
      "isLocationVerified": false,
      "breakTime": "1h 0m",
      "overtime": "0h 0m",
      "accuracy": "N/A"
    },
    {
      "date": "2025-01-09",
      "status": "present",
      "checkIn": "08:55",
      "checkOut": "18:25",
      "totalHours": "8h 30m",
      "location": "Office Building A, Floor 3",
      "isLocationVerified": true,
      "breakTime": "1h 0m",
      "overtime": "0h 30m",
      "accuracy": "±3 meters"
    }
  ];

  // Mock analytics data
  final Map<String, dynamic> _analyticsData = {
    "totalHours": 156.5,
    "averageHours": 7.8,
    "punctualityScore": 92.0,
    "wfhDays": 4,
    "weeklyData": [
      {"day": "Mon", "hours": 8.5},
      {"day": "Tue", "hours": 7.8},
      {"day": "Wed", "hours": 9.2},
      {"day": "Thu", "hours": 8.1},
      {"day": "Fri", "hours": 8.7},
      {"day": "Sat", "hours": 6.5},
      {"day": "Sun", "hours": 0.0}
    ]
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          _buildTabBar(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildCalendarView(),
                _buildAnalyticsView(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      elevation: 2,
      leading: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Container(
          margin: EdgeInsets.all(2.w),
          decoration: BoxDecoration(
            color:
                AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: CustomIconWidget(
            iconName: 'arrow_back',
            color: AppTheme.lightTheme.colorScheme.primary,
            size: 20,
          ),
        ),
      ),
      title: Text(
        'Attendance History',
        style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
          fontWeight: FontWeight.w600,
        ),
      ),
      actions: [
        GestureDetector(
          onTap: _showFilterBottomSheet,
          child: Container(
            margin: EdgeInsets.only(right: 2.w),
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.primary
                  .withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: CustomIconWidget(
              iconName: 'filter_list',
              color: AppTheme.lightTheme.colorScheme.primary,
              size: 20,
            ),
          ),
        ),
        GestureDetector(
          onTap: _exportAttendanceReport,
          child: Container(
            margin: EdgeInsets.only(right: 4.w),
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.primary
                  .withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: CustomIconWidget(
              iconName: 'download',
              color: AppTheme.lightTheme.colorScheme.primary,
              size: 20,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTabBar() {
    return Container(
      color: AppTheme.lightTheme.colorScheme.surface,
      child: TabBar(
        controller: _tabController,
        labelColor: AppTheme.lightTheme.colorScheme.primary,
        unselectedLabelColor:
            AppTheme.lightTheme.colorScheme.onSurface.withValues(alpha: 0.6),
        indicatorColor: AppTheme.lightTheme.colorScheme.primary,
        indicatorWeight: 3,
        tabs: const [
          Tab(text: 'Calendar View'),
          Tab(text: 'Analytics'),
        ],
      ),
    );
  }

  Widget _buildCalendarView() {
    return RefreshIndicator(
      onRefresh: _refreshAttendanceData,
      color: AppTheme.lightTheme.colorScheme.primary,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: EdgeInsets.all(4.w),
        child: Column(
          children: [
            _buildSearchBar(),
            SizedBox(height: 2.h),
            CalendarWidget(
              selectedDate: _selectedDate,
              onDateSelected: _onDateSelected,
              attendanceData: _getAttendanceDataForCalendar(),
            ),
            SizedBox(height: 3.h),
            _buildAttendanceList(),
          ],
        ),
      ),
    );
  }

  Widget _buildAnalyticsView() {
    return RefreshIndicator(
      onRefresh: _refreshAttendanceData,
      color: AppTheme.lightTheme.colorScheme.primary,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: EdgeInsets.all(4.w),
        child: Column(
          children: [
            AnalyticsSummaryWidget(analyticsData: _analyticsData),
            SizedBox(height: 3.h),
            _buildQuickStats(),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.dividerColor,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          CustomIconWidget(
            iconName: 'search',
            color: AppTheme.lightTheme.colorScheme.onSurface
                .withValues(alpha: 0.6),
            size: 20,
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: TextField(
              controller: _searchController,
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                });
              },
              decoration: InputDecoration(
                hintText: 'Search by date or status...',
                border: InputBorder.none,
                hintStyle: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurface
                      .withValues(alpha: 0.6),
                ),
              ),
              style: AppTheme.lightTheme.textTheme.bodyMedium,
            ),
          ),
          if (_searchQuery.isNotEmpty)
            GestureDetector(
              onTap: () {
                _searchController.clear();
                setState(() {
                  _searchQuery = '';
                });
              },
              child: CustomIconWidget(
                iconName: 'clear',
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.6),
                size: 20,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildAttendanceList() {
    final filteredData = _getFilteredAttendanceData();

    if (filteredData.isEmpty) {
      return Container(
        padding: EdgeInsets.all(8.w),
        child: Column(
          children: [
            CustomIconWidget(
              iconName: 'event_busy',
              color: AppTheme.lightTheme.colorScheme.onSurface
                  .withValues(alpha: 0.4),
              size: 48,
            ),
            SizedBox(height: 2.h),
            Text(
              'No attendance records found',
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.6),
              ),
            ),
            SizedBox(height: 1.h),
            Text(
              'Try adjusting your filters or search criteria',
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.4),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 2.w),
          child: Text(
            'Recent Attendance (${filteredData.length} records)',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        SizedBox(height: 2.h),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: filteredData.length,
          itemBuilder: (context, index) {
            return AttendanceCardWidget(
              attendanceData: filteredData[index],
              onTap: () => _showAttendanceDetails(filteredData[index]),
            );
          },
        ),
      ],
    );
  }

  Widget _buildQuickStats() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: AppTheme.lightTheme.shadowColor.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Quick Stats',
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 3.h),
          _buildStatRow('This Month', '22 days', 'Present'),
          _buildStatRow('Last 7 Days', '5 days', 'Present'),
          _buildStatRow('WFH This Month', '4 days', 'Remote'),
          _buildStatRow('Average Check-in', '9:08 AM', 'On Time'),
          _buildStatRow('Overtime Hours', '12.5 hours', 'Extra'),
        ],
      ),
    );
  }

  Widget _buildStatRow(String label, String value, String status) {
    return Padding(
      padding: EdgeInsets.only(bottom: 2.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurface
                      .withValues(alpha: 0.6),
                ),
              ),
              SizedBox(height: 0.5.h),
              Text(
                value,
                style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
            decoration: BoxDecoration(
              color: AppTheme.getSuccessColor(true).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text(
              status,
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.getSuccessColor(true),
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _onDateSelected(DateTime date) {
    setState(() {
      _selectedDate = date;
    });
  }

  void _showFilterBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => FilterBottomSheetWidget(
        currentFilters: _currentFilters,
        onFiltersApplied: (filters) {
          setState(() {
            _currentFilters = filters;
          });
        },
      ),
    );
  }

  void _showAttendanceDetails(Map<String, dynamic> attendanceData) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Attendance Details',
          style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Date: ${attendanceData['date']}',
              style: AppTheme.lightTheme.textTheme.bodyMedium,
            ),
            SizedBox(height: 1.h),
            Text(
              'Status: ${attendanceData['status']}',
              style: AppTheme.lightTheme.textTheme.bodyMedium,
            ),
            if (attendanceData['location'] != null) ...[
              SizedBox(height: 1.h),
              Text(
                'Location: ${attendanceData['location']}',
                style: AppTheme.lightTheme.textTheme.bodyMedium,
              ),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Future<void> _refreshAttendanceData() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate API call
    await Future.delayed(const Duration(seconds: 1));

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _exportAttendanceReport() async {
    try {
      final reportData = _generateReportData();
      final csvContent = _convertToCSV(reportData);

      await _downloadFile(csvContent,
          'attendance_report_${DateTime.now().millisecondsSinceEpoch}.csv');

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Attendance report exported successfully'),
          backgroundColor: AppTheme.getSuccessColor(true),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Failed to export report'),
          backgroundColor: AppTheme.lightTheme.colorScheme.error,
        ),
      );
    }
  }

  Future<void> _downloadFile(String content, String filename) async {
    if (kIsWeb) {
      final bytes = utf8.encode(content);
      final blob = html.Blob([bytes]);
      final url = html.Url.createObjectUrlFromBlob(blob);
      final anchor = html.AnchorElement(href: url)
        ..setAttribute("download", filename)
        ..click();
      html.Url.revokeObjectUrl(url);
    } else {
      // For mobile platforms, you would typically use path_provider
      // This is a simplified implementation
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Report saved as $filename'),
          backgroundColor: AppTheme.getSuccessColor(true),
        ),
      );
    }
  }

  List<Map<String, dynamic>> _generateReportData() {
    return _attendanceHistory
        .map((record) => {
              'Date': record['date'],
              'Status': record['status'],
              'Check In': record['checkIn'] ?? 'N/A',
              'Check Out': record['checkOut'] ?? 'N/A',
              'Total Hours': record['totalHours'] ?? 'N/A',
              'Location': record['location'] ?? 'N/A',
              'Verified': record['isLocationVerified'] ? 'Yes' : 'No',
            })
        .toList();
  }

  String _convertToCSV(List<Map<String, dynamic>> data) {
    if (data.isEmpty) return '';

    final headers = data.first.keys.join(',');
    final rows = data.map((row) => row.values.join(',')).join('\n');

    return '$headers\n$rows';
  }

  Map<DateTime, String> _getAttendanceDataForCalendar() {
    final Map<DateTime, String> calendarData = {};

    for (final record in _attendanceHistory) {
      final date = DateTime.parse(record['date'] as String);
      final status = record['status'] as String;
      calendarData[date] = status;
    }

    return calendarData;
  }

  List<Map<String, dynamic>> _getFilteredAttendanceData() {
    List<Map<String, dynamic>> filtered = List.from(_attendanceHistory);

    // Apply search filter
    if (_searchQuery.isNotEmpty) {
      filtered = filtered.where((record) {
        final date = record['date'] as String;
        final status = record['status'] as String;
        return date.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            status.toLowerCase().contains(_searchQuery.toLowerCase());
      }).toList();
    }

    // Apply attendance type filter
    if (_currentFilters['attendanceType'] != null &&
        _currentFilters['attendanceType'] != 'All') {
      final filterType =
          (_currentFilters['attendanceType'] as String).toLowerCase();
      filtered = filtered.where((record) {
        final status = (record['status'] as String).toLowerCase();
        return status == filterType;
      }).toList();
    }

    // Apply location verification filter
    if (_currentFilters['locationVerification'] != null &&
        _currentFilters['locationVerification'] != 'All') {
      final isVerifiedFilter =
          _currentFilters['locationVerification'] == 'Verified';
      filtered = filtered.where((record) {
        final isVerified = record['isLocationVerified'] as bool? ?? false;
        return isVerified == isVerifiedFilter;
      }).toList();
    }

    // Apply date range filter
    if (_currentFilters['startDate'] != null &&
        _currentFilters['endDate'] != null) {
      final startDate = DateTime.parse(_currentFilters['startDate'] as String);
      final endDate = DateTime.parse(_currentFilters['endDate'] as String);

      filtered = filtered.where((record) {
        final recordDate = DateTime.parse(record['date'] as String);
        return recordDate
                .isAfter(startDate.subtract(const Duration(days: 1))) &&
            recordDate.isBefore(endDate.add(const Duration(days: 1)));
      }).toList();
    }

    return filtered;
  }
}
