import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class FilterBottomSheetWidget extends StatefulWidget {
  final Map<String, dynamic> currentFilters;
  final Function(Map<String, dynamic>) onFiltersApplied;

  const FilterBottomSheetWidget({
    Key? key,
    required this.currentFilters,
    required this.onFiltersApplied,
  }) : super(key: key);

  @override
  State<FilterBottomSheetWidget> createState() =>
      _FilterBottomSheetWidgetState();
}

class _FilterBottomSheetWidgetState extends State<FilterBottomSheetWidget> {
  late Map<String, dynamic> _filters;
  DateTimeRange? _selectedDateRange;

  @override
  void initState() {
    super.initState();
    _filters = Map<String, dynamic>.from(widget.currentFilters);

    if (_filters['startDate'] != null && _filters['endDate'] != null) {
      _selectedDateRange = DateTimeRange(
          start: DateTime.parse(_filters['startDate'] as String),
          end: DateTime.parse(_filters['endDate'] as String));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
            color: AppTheme.lightTheme.colorScheme.surface,
            borderRadius:
                const BorderRadius.vertical(top: Radius.circular(20))),
        child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(),
              SizedBox(height: 3.h),
              _buildDateRangeSection(),
              SizedBox(height: 3.h),
              _buildAttendanceTypeSection(),
              SizedBox(height: 3.h),
              _buildLocationVerificationSection(),
              SizedBox(height: 4.h),
              _buildActionButtons(),
              SizedBox(height: 2.h),
            ]));
  }

  Widget _buildHeader() {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text('Filter Attendance',
          style: AppTheme.lightTheme.textTheme.titleLarge
              ?.copyWith(fontWeight: FontWeight.w600)),
      GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.onSurface
                      .withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8)),
              child: CustomIconWidget(
                  iconName: 'close',
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                  size: 20))),
    ]);
  }

  Widget _buildDateRangeSection() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Date Range',
          style: AppTheme.lightTheme.textTheme.titleMedium
              ?.copyWith(fontWeight: FontWeight.w600)),
      SizedBox(height: 2.h),
      GestureDetector(
          onTap: _selectDateRange,
          child: Container(
              width: double.infinity,
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                  border: Border.all(
                      color: AppTheme.lightTheme.dividerColor, width: 1),
                  borderRadius: BorderRadius.circular(8)),
              child: Row(children: [
                CustomIconWidget(
                    iconName: 'date_range',
                    color: AppTheme.lightTheme.colorScheme.primary,
                    size: 20),
                SizedBox(width: 3.w),
                Expanded(
                    child: Text(
                        _selectedDateRange != null
                            ? '${_formatDate(_selectedDateRange!.start)} - ${_formatDate(_selectedDateRange!.end)}'
                            : 'Select date range',
                        style: AppTheme.lightTheme.textTheme.bodyMedium
                            ?.copyWith(
                                color: _selectedDateRange != null
                                    ? AppTheme.lightTheme.colorScheme.onSurface
                                    : AppTheme.lightTheme.colorScheme.onSurface
                                        .withValues(alpha: 0.6)))),
                CustomIconWidget(
                    iconName: 'chevron_right',
                    color: AppTheme.lightTheme.colorScheme.onSurface
                        .withValues(alpha: 0.6),
                    size: 20),
              ]))),
    ]);
  }

  Widget _buildAttendanceTypeSection() {
    final attendanceTypes = ['All', 'Present', 'Absent', 'WFH', 'Holiday'];
    final selectedType = _filters['attendanceType'] as String? ?? 'All';

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Attendance Type',
          style: AppTheme.lightTheme.textTheme.titleMedium
              ?.copyWith(fontWeight: FontWeight.w600)),
      SizedBox(height: 2.h),
      Wrap(
          spacing: 2.w,
          runSpacing: 1.h,
          children: attendanceTypes.map((type) {
            final isSelected = selectedType == type;
            return GestureDetector(
                onTap: () {
                  setState(() {
                    _filters['attendanceType'] = type;
                  });
                },
                child: Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
                    decoration: BoxDecoration(
                        color: isSelected
                            ? AppTheme.lightTheme.colorScheme.primary
                            : AppTheme.lightTheme.colorScheme.surface,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: isSelected
                                ? AppTheme.lightTheme.colorScheme.primary
                                : AppTheme.lightTheme.dividerColor,
                            width: 1)),
                    child: Text(type,
                        style: AppTheme.lightTheme.textTheme.bodySmall
                            ?.copyWith(
                                color: isSelected
                                    ? AppTheme.lightTheme.colorScheme.onPrimary
                                    : AppTheme.lightTheme.colorScheme.onSurface,
                                fontWeight: isSelected
                                    ? FontWeight.w500
                                    : FontWeight.w400))));
          }).toList()),
    ]);
  }

  Widget _buildLocationVerificationSection() {
    final verificationOptions = ['All', 'Verified', 'Not Verified'];
    final selectedOption = _filters['locationVerification'] as String? ?? 'All';

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Location Verification',
          style: AppTheme.lightTheme.textTheme.titleMedium
              ?.copyWith(fontWeight: FontWeight.w600)),
      SizedBox(height: 2.h),
      Column(
          children: verificationOptions.map((option) {
        final isSelected = selectedOption == option;
        return GestureDetector(
            onTap: () {
              setState(() {
                _filters['locationVerification'] = option;
              });
            },
            child: Container(
                width: double.infinity,
                padding: EdgeInsets.all(3.w),
                margin: EdgeInsets.only(bottom: 1.h),
                decoration: BoxDecoration(
                    color: isSelected
                        ? AppTheme.lightTheme.colorScheme.primary
                            .withValues(alpha: 0.1)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                        color: isSelected
                            ? AppTheme.lightTheme.colorScheme.primary
                            : AppTheme.lightTheme.dividerColor,
                        width: 1)),
                child: Row(children: [
                  Container(
                      width: 5.w,
                      height: 5.w,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: isSelected
                                  ? AppTheme.lightTheme.colorScheme.primary
                                  : AppTheme.lightTheme.colorScheme.onSurface
                                      .withValues(alpha: 0.3),
                              width: 2)),
                      child: isSelected
                          ? Center(
                              child: Container(
                                  width: 2.w,
                                  height: 2.w,
                                  decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: AppTheme
                                          .lightTheme.colorScheme.primary)))
                          : null),
                  SizedBox(width: 3.w),
                  Text(option,
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                          color: isSelected
                              ? AppTheme.lightTheme.colorScheme.primary
                              : AppTheme.lightTheme.colorScheme.onSurface,
                          fontWeight:
                              isSelected ? FontWeight.w500 : FontWeight.w400)),
                ])));
      }).toList()),
    ]);
  }

  Widget _buildActionButtons() {
    return Row(children: [
      Expanded(
          child: OutlinedButton(
              onPressed: _clearFilters, child: const Text('Clear All'))),
      SizedBox(width: 4.w),
      Expanded(
          child: ElevatedButton(
              onPressed: _applyFilters, child: const Text('Apply Filters'))),
    ]);
  }

  void _selectDateRange() async {
    final DateTimeRange? picked = await showDateRangePicker(
        context: context,
        firstDate: DateTime.now().subtract(const Duration(days: 365)),
        lastDate: DateTime.now(),
        initialDateRange: _selectedDateRange,
        builder: (context, child) {
          return DatePickerTheme(
              data: DatePickerThemeData(
                  backgroundColor: AppTheme.lightTheme.colorScheme.surface,
                  headerBackgroundColor:
                      AppTheme.lightTheme.colorScheme.primary,
                  headerForegroundColor:
                      AppTheme.lightTheme.colorScheme.onPrimary,
                  rangeSelectionBackgroundColor: AppTheme
                      .lightTheme.colorScheme.primary
                      .withValues(alpha: 0.3)),
              child: child!);
        });

    if (picked != null) {
      setState(() {
        _selectedDateRange = picked;
        _filters['startDate'] = picked.start.toIso8601String();
        _filters['endDate'] = picked.end.toIso8601String();
      });
    }
  }

  void _clearFilters() {
    setState(() {
      _filters.clear();
      _selectedDateRange = null;
    });
  }

  void _applyFilters() {
    widget.onFiltersApplied(_filters);
    Navigator.pop(context);
  }

  String _formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
  }
}
