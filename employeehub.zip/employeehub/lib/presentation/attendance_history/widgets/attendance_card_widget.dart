import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class AttendanceCardWidget extends StatefulWidget {
  final Map<String, dynamic> attendanceData;
  final VoidCallback? onTap;

  const AttendanceCardWidget({
    Key? key,
    required this.attendanceData,
    this.onTap,
  }) : super(key: key);

  @override
  State<AttendanceCardWidget> createState() => _AttendanceCardWidgetState();
}

class _AttendanceCardWidgetState extends State<AttendanceCardWidget>
    with SingleTickerProviderStateMixin {
  bool _isExpanded = false;
  late AnimationController _animationController;
  late Animation<double> _expandAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _expandAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final date = DateTime.parse(widget.attendanceData['date'] as String);
    final status = widget.attendanceData['status'] as String;
    final checkIn = widget.attendanceData['checkIn'] as String?;
    final checkOut = widget.attendanceData['checkOut'] as String?;
    final totalHours = widget.attendanceData['totalHours'] as String?;
    final location = widget.attendanceData['location'] as String?;
    final isVerified =
        widget.attendanceData['isLocationVerified'] as bool? ?? false;

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: () {
          setState(() {
            _isExpanded = !_isExpanded;
            if (_isExpanded) {
              _animationController.forward();
            } else {
              _animationController.reverse();
            }
          });
          widget.onTap?.call();
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: EdgeInsets.all(4.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildCardHeader(date, status),
              SizedBox(height: 2.h),
              _buildMainContent(checkIn, checkOut, totalHours, isVerified),
              AnimatedBuilder(
                animation: _expandAnimation,
                builder: (context, child) {
                  return SizeTransition(
                    sizeFactor: _expandAnimation,
                    child: child,
                  );
                },
                child: _buildExpandedContent(location),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCardHeader(DateTime date, String status) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _formatDate(date),
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 0.5.h),
            Text(
              _formatWeekday(date),
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.6),
              ),
            ),
          ],
        ),
        _buildStatusBadge(status),
      ],
    );
  }

  Widget _buildStatusBadge(String status) {
    Color backgroundColor;
    Color textColor;
    String displayText;

    switch (status.toLowerCase()) {
      case 'present':
        backgroundColor = AppTheme.getSuccessColor(true).withValues(alpha: 0.1);
        textColor = AppTheme.getSuccessColor(true);
        displayText = 'Present';
        break;
      case 'absent':
        backgroundColor =
            AppTheme.lightTheme.colorScheme.error.withValues(alpha: 0.1);
        textColor = AppTheme.lightTheme.colorScheme.error;
        displayText = 'Absent';
        break;
      case 'wfh':
        backgroundColor =
            AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1);
        textColor = AppTheme.lightTheme.colorScheme.primary;
        displayText = 'WFH';
        break;
      case 'holiday':
        backgroundColor =
            AppTheme.lightTheme.colorScheme.onSurface.withValues(alpha: 0.1);
        textColor =
            AppTheme.lightTheme.colorScheme.onSurface.withValues(alpha: 0.6);
        displayText = 'Holiday';
        break;
      default:
        backgroundColor = AppTheme.getWarningColor(true).withValues(alpha: 0.1);
        textColor = AppTheme.getWarningColor(true);
        displayText = 'Pending';
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        displayText,
        style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
          color: textColor,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildMainContent(
      String? checkIn, String? checkOut, String? totalHours, bool isVerified) {
    return Row(
      children: [
        Expanded(
          child: _buildTimeInfo('Check In', checkIn ?? '--:--', 'login'),
        ),
        Container(
          width: 1,
          height: 6.h,
          color: AppTheme.lightTheme.dividerColor,
          margin: EdgeInsets.symmetric(horizontal: 2.w),
        ),
        Expanded(
          child: _buildTimeInfo('Check Out', checkOut ?? '--:--', 'logout'),
        ),
        SizedBox(width: 2.w),
        Column(
          children: [
            Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: isVerified
                    ? AppTheme.getSuccessColor(true).withValues(alpha: 0.1)
                    : AppTheme.getWarningColor(true).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: CustomIconWidget(
                iconName: isVerified ? 'verified' : 'location_off',
                color: isVerified
                    ? AppTheme.getSuccessColor(true)
                    : AppTheme.getWarningColor(true),
                size: 20,
              ),
            ),
            SizedBox(height: 1.h),
            Text(
              totalHours ?? '0h 0m',
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildTimeInfo(String label, String time, String iconName) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            CustomIconWidget(
              iconName: iconName,
              color: AppTheme.lightTheme.colorScheme.primary,
              size: 16,
            ),
            SizedBox(width: 1.w),
            Text(
              label,
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.6),
              ),
            ),
          ],
        ),
        SizedBox(height: 0.5.h),
        Text(
          time,
          style: AppTheme.dataTextStyle(
            isLight: true,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _buildExpandedContent(String? location) {
    if (!_isExpanded) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 2.h),
        Divider(color: AppTheme.lightTheme.dividerColor),
        SizedBox(height: 2.h),
        Text(
          'Details',
          style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.h),
        if (location != null) ...[
          Row(
            children: [
              CustomIconWidget(
                iconName: 'location_on',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 16,
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: Text(
                  location,
                  style: AppTheme.lightTheme.textTheme.bodySmall,
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
        ],
        _buildDetailRow('Break Time', '1h 0m'),
        _buildDetailRow('Overtime', '0h 30m'),
        _buildDetailRow('Location Accuracy', '±5 meters'),
      ],
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.only(bottom: 0.5.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurface
                  .withValues(alpha: 0.6),
            ),
          ),
          Text(
            value,
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
  }

  String _formatWeekday(DateTime date) {
    final weekdays = [
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday'
    ];
    return weekdays[date.weekday % 7];
  }
}
