import 'package:flutter/material.dart';
import '../presentation/login_screen/login_screen.dart';
import '../presentation/leave_request/leave_request.dart';
import '../presentation/dashboard/dashboard.dart';
import '../presentation/request_history/request_history.dart';
import '../presentation/attendance_history/attendance_history.dart';
import '../presentation/attendance_check_in/attendance_check_in.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String loginScreen = '/login-screen';
  static const String leaveRequest = '/leave-request';
  static const String dashboard = '/dashboard';
  static const String requestHistory = '/request-history';
  static const String attendanceHistory = '/attendance-history';
  static const String attendanceCheckIn = '/attendance-check-in';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => LoginScreen(),
    loginScreen: (context) => LoginScreen(),
    leaveRequest: (context) => LeaveRequest(),
    dashboard: (context) => Dashboard(),
    requestHistory: (context) => RequestHistory(),
    attendanceHistory: (context) => AttendanceHistory(),
    attendanceCheckIn: (context) => AttendanceCheckIn(),
    // TODO: Add your other routes here
  };
}
